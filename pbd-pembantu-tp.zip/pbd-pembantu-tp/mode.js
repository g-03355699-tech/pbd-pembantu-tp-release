// mod panel terapung (skrip sebaris tidak dibenarkan dalam MV3)
if (location.search.includes('float=1')) document.documentElement.classList.add('float');
