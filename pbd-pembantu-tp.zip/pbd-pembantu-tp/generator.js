/*
 * PBD Pembantu TP — penjana Ulasan Guru Kelas
 * Menjana ulasan Bahasa Melayu yang khusus kepada setiap murid
 * berdasarkan profil TP semua mata pelajaran. Tiada sambungan internet.
 */
'use strict';

const GK_DEFAULT_SUBJECTS = `BM=Bahasa Melayu
BI=Bahasa Inggeris
MM=Matematik
SAINS=Sains
SEJ=Sejarah
PAI=Pendidikan Islam
PM=Pendidikan Moral
BCKOM=Bahasa Cina Komunikasi
BKR=Bahasa Korea
BJP=Bahasa Jepun
BJR=Bahasa Jerman
BA=Bahasa Arab
BP=Bahasa Perancis
RBT=Reka Bentuk dan Teknologi
GEO=Geografi
ASK=Asas Sains Komputer
PSV=Pendidikan Seni Visual
PJPK=Pendidikan Jasmani dan Kesihatan`;

const GK_TIPS = {
  BM: 'memperbanyak bacaan dan latihan penulisan karangan',
  BI: 'membaca bahan bacaan bahasa Inggeris dan berlatih bertutur dengan yakin',
  MM: 'membuat latihan pengiraan secara konsisten setiap hari',
  SAINS: 'mengukuhkan kefahaman konsep dan membuat latihan soalan berasaskan eksperimen',
  SEJ: 'membuat peta minda dan nota ringkas bagi fakta sejarah penting',
  PAI: 'mengukuhkan kefahaman dan amalan dalam kehidupan seharian',
  PM: 'mengukuhkan kefahaman nilai murni dan mengamalkannya',
  GEO: 'mengukuhkan kemahiran membaca peta dan menghafal fakta geografi',
  RBT: 'lebih aktif dalam kerja projek dan kemahiran reka bentuk',
  ASK: 'berlatih menulis algoritma dan atur cara secara berterusan',
  PSV: 'berlatih menghasilkan karya dengan lebih kerap',
  PJPK: 'lebih aktif melibatkan diri dalam aktiviti fizikal',
  _lang: 'menambah kosa kata dan berlatih bertutur secara konsisten',
  _default: 'mengulang kaji secara konsisten dan membuat lebih banyak latihan',
};

const GK_PRIORITY = ['BM', 'BI', 'MM', 'SAINS', 'SEJ', 'GEO', 'ASK', 'RBT', 'PAI', 'PM', 'PSV', 'PJPK'];
const GK_THIRD_LANG = /^(BCKOM|BKR|BJP|BJR|BA|BP|BC|BT|BKD|BIB|BS)$/;
const GK_SKIP_NICK = new Set(['MUHAMMAD', 'MUHAMAD', 'MUHD', 'MOHD', 'MOHAMAD', 'MOHAMMAD', 'MOHAMED', 'MOHAMMED', 'MD', 'NUR', 'NURUL', 'NOR', 'NOOR', 'SITI', 'NIK', 'WAN', 'TENGKU', 'TUNKU', 'RAJA', 'SYED', 'SHARIFAH', 'SHARIFFAH', 'PUTERI', 'PUTRI', 'AWANG', 'DAYANG', 'ABANG', 'AHMAD', 'ABDUL', 'ABD', 'MEGAT', 'NIK', 'ENGKU', 'CHE', 'AB', 'AL', 'MOHD.']);

function gkParseSubjects(text) {
  const m = {};
  String(text || '').split(/\r?\n/).forEach((l) => {
    const i = l.indexOf('=');
    if (i > 0) m[l.slice(0, i).trim().toUpperCase()] = l.slice(i + 1).trim();
  });
  return m;
}

function gkTitle(s) {
  return s.toLowerCase().replace(/(^|[\s-])([a-z])/g, (a, b, c) => b + c.toUpperCase());
}

function gkNick(fullName) {
  const name = String(fullName || '').toUpperCase().replace(/^['`]+/, '');
  const head = name.split(/\s+(BIN|BINTI|BTE|BT|A\/L|A\/P|AL|AP)\s+/)[0];
  const toks = head.split(/\s+/).map((t) => t.replace(/^['`]+/, '')).filter(Boolean);
  if (!toks.length) return '';
  // nama tanpa bin/binti (cth. nama Cina) — guna dua perkataan terakhir jika 3 perkataan
  const pick = toks.find((t) => !GK_SKIP_NICK.has(t)) || toks[toks.length - 1];
  return gkTitle(pick);
}

function gkJoin(list) {
  if (list.length <= 1) return list.join('');
  return list.slice(0, -1).join(', ') + ' dan ' + list[list.length - 1];
}

// penjana nombor rawak berbiji supaya hasil boleh diulang (biji berubah bila "Jana semula")
function gkRng(seed) {
  let h = 2166136261;
  for (const ch of String(seed)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); }
  return () => {
    h += 0x6D2B79F5;
    let t = h;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function gkGenerate(student, opts = {}) {
  const names = { ...gkParseSubjects(GK_DEFAULT_SUBJECTS), ...(opts.subjectNames || {}) };
  const rnd = gkRng((student.ic || student.name) + '|' + (opts.seed || 0));
  const pick = (arr) => arr[Math.floor(rnd() * arr.length)];
  const nm = (c) => names[c] || c;
  const order = (codes) => codes.slice().sort((a, b) => {
    const ia = GK_PRIORITY.indexOf(a), ib = GK_PRIORITY.indexOf(b);
    return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
  });

  const subj = Object.entries(student.subjects || {}).filter(([, v]) => v >= 1 && v <= 6);
  if (!subj.length) return '';
  const tps = subj.map(([, v]) => v);
  const n = tps.length;
  const avg = tps.reduce((a, b) => a + b, 0) / n;
  const max = Math.max(...tps), min = Math.min(...tps);
  const at = (v) => order(subj.filter(([, t]) => t === v).map(([c]) => c));
  const top = at(max);
  const low = min < max ? at(min) : [];
  const nick = opts.useName === false ? '' : gkNick(student.name);
  const S = nick || pick(['Murid ini', 'Beliau']);
  const s2 = nick ? pick([nick, 'Beliau']) : 'Beliau';

  const out = [];

  // 1) Gambaran keseluruhan
  if (avg >= 5.75) {
    out.push(pick([
      `${S} merupakan murid yang cemerlang dengan penguasaan tahap tertinggi dalam hampir semua mata pelajaran.`,
      `${S} menunjukkan prestasi yang sangat cemerlang dan konsisten merentasi semua mata pelajaran.`,
      `Tahniah kepada ${S} atas pencapaian cemerlang yang menyeluruh dalam pentaksiran tahun ini.`,
    ]));
  } else if (avg >= 5.3) {
    out.push(pick([
      `${S} menunjukkan pencapaian yang sangat baik dan konsisten dalam kebanyakan mata pelajaran.`,
      `${S} ialah murid yang berpotensi tinggi dengan prestasi akademik yang sangat memberangsangkan.`,
      `Secara keseluruhan, ${S} mencapai tahap penguasaan yang sangat baik dalam pentaksiran tahun ini.`,
    ]));
  } else if (avg >= 4.6) {
    out.push(pick([
      `${S} menunjukkan pencapaian yang baik secara keseluruhan.`,
      `${S} mempunyai asas penguasaan yang baik dan mampu mencapai tahap yang lebih tinggi.`,
      `Prestasi ${S} secara keseluruhan adalah baik dan stabil.`,
    ]));
  } else if (avg >= 3.5) {
    out.push(pick([
      `${S} menunjukkan penguasaan yang memuaskan dalam kebanyakan mata pelajaran.`,
      `${S} telah menguasai asas pembelajaran dengan memuaskan dan berpotensi untuk terus maju.`,
    ]));
  } else {
    out.push(pick([
      `${S} memerlukan bimbingan dan sokongan yang lebih untuk meningkatkan penguasaan dalam pembelajaran.`,
      `Pencapaian ${S} masih boleh dipertingkatkan dengan usaha dan bimbingan yang berterusan.`,
    ]));
  }

  // 2) Kekuatan
  if (max >= 5) {
    const level = max === 6 ? 'cemerlang' : 'sangat baik';
    if (top.length >= 6 && top.length >= n - 2) {
      out.push(pick([
        `${s2} menguasai ${top.length} daripada ${n} mata pelajaran pada tahap ${level}, termasuk ${gkJoin(top.slice(0, 3).map(nm))}.`,
        `Penguasaan ${level} ditunjukkan dalam ${top.length} mata pelajaran, antaranya ${gkJoin(top.slice(0, 3).map(nm))}.`,
      ]));
    } else {
      const lst = gkJoin(top.slice(0, 3).map(nm));
      out.push(pick([
        `Kekuatan ${s2 === 'Beliau' ? 'beliau' : s2} jelas dalam ${lst}.`,
        `${s2} menonjol dalam ${lst} dengan penguasaan ${level}.`,
        `Penguasaan ${level} dalam ${lst} amat membanggakan.`,
      ]));
    }
    // ciri tambahan
    const extras = [];
    const t = student.subjects;
    if (t.BM === 6 && t.BI === 6) extras.push('Kemahiran berbahasa dalam Bahasa Melayu dan Bahasa Inggeris juga sangat baik.');
    if (t.MM === 6 && (t.SAINS === 6 || t.ASK === 6)) extras.push('Beliau juga menunjukkan kebolehan berfikir secara logik dan analitis.');
    const third = Object.keys(t).filter((c) => GK_THIRD_LANG.test(c) && t[c] === 6);
    if (third.length) extras.push(`Penguasaan ${nm(third[0])} sebagai bahasa tambahan amat membanggakan.`);
    if (t.PJPK === 6 && avg >= 5) extras.push('Beliau turut seimbang dari segi akademik dan aktiviti fizikal.');
    if (extras.length && rnd() < 0.7) out.push(pick(extras));
  }

  // 3) Ruang penambahbaikan
  if (low.length) {
    const focus = low.slice(0, 2);
    const tipOf = (c) => GK_TIPS[c] || (GK_THIRD_LANG.test(c) ? GK_TIPS._lang : GK_TIPS._default);
    const tip = focus.length > 1 && tipOf(focus[0]) !== tipOf(focus[1]) ? GK_TIPS._default : tipOf(focus[0]);
    if (min <= 3) {
      out.push(pick([
        `Walau bagaimanapun, ${gkJoin(focus.map(nm))} perlu diberi perhatian serius dengan ${tip}.`,
        `${s2} perlu memberi tumpuan lebih kepada ${gkJoin(focus.map(nm))} dengan ${tip}.`,
      ]));
    } else if (min === 4) {
      out.push(pick([
        `Penguasaan dalam ${gkJoin(focus.map(nm))} boleh ditingkatkan lagi dengan ${tip}.`,
        `${s2} digalakkan ${tip} bagi meningkatkan pencapaian dalam ${gkJoin(focus.map(nm))}.`,
        `Tumpuan tambahan dalam ${gkJoin(focus.map(nm))} akan membantu ${s2 === 'Beliau' ? 'beliau' : s2} mencapai prestasi yang lebih seimbang.`,
      ]));
    } else {
      out.push(pick([
        `${s2} berpotensi mencapai tahap tertinggi dalam ${gkJoin(focus.map(nm))} dengan sedikit usaha tambahan.`,
        `Sedikit usaha lagi dalam ${gkJoin(focus.map(nm))} akan menjadikan pencapaian ${s2 === 'Beliau' ? 'beliau' : s2} lebih cemerlang.`,
      ]));
    }
  }

  // 4) Penutup
  if (avg >= 5.3) {
    out.push(pick([
      'Teruskan usaha dan kekalkan prestasi cemerlang ini.',
      'Semoga terus konsisten dan menjadi contoh kepada rakan-rakan.',
      'Kekalkan semangat dan disiplin belajar yang tinggi ini.',
      'Teruskan kecemerlangan dan jangan cepat berpuas hati.',
    ]));
  } else if (avg >= 4.3) {
    out.push(pick([
      'Teruskan berusaha dengan lebih gigih untuk mencapai kecemerlangan.',
      'Dengan usaha yang berterusan, prestasi yang lebih baik pasti dapat dicapai.',
      'Tingkatkan usaha dan kekalkan sikap positif dalam pembelajaran.',
    ]));
  } else {
    out.push(pick([
      'Guru yakin dengan usaha gigih dan bimbingan berterusan, prestasi akan terus meningkat.',
      'Jangan berputus asa dan teruskan berusaha dengan bersungguh-sungguh.',
    ]));
  }

  let text = out.join(' ').replace(/\s+/g, ' ').trim();
  if (opts.maxLen && text.length > opts.maxLen) {
    const parts = out.slice();
    while (parts.length > 2 && parts.join(' ').length > opts.maxLen) parts.splice(parts.length - 2, 1);
    text = parts.join(' ');
    if (text.length > opts.maxLen) text = text.slice(0, opts.maxLen - 1).replace(/\s\S*$/, '') + '.';
  }
  return text;
}

if (typeof module !== 'undefined') module.exports = { gkGenerate, gkNick, gkParseSubjects, GK_DEFAULT_SUBJECTS };
