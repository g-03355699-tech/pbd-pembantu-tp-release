/* PBD Pembantu TP — logik popup */
'use strict';

const $ = (id) => document.getElementById(id);
let tabId = null;
let pageHeaders = [];
let bulkTp = null;
let imported = null; // { records, tpCols, mapped, count }

// ---------- Komunikasi dengan halaman ----------

async function runAll(cmd, args) {
  await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    files: ['content.js'],
  });
  const res = await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    func: (c, a) => (window.__pbdHelper ? window.__pbdHelper.run(c, a) : { error: 'tiada helper' }),
    args: [cmd, args || {}],
  });
  return res.map((r) => r.result).filter(Boolean);
}

function sum(list, key) {
  return list.reduce((n, r) => n + (Number(r[key]) || 0), 0);
}

function uniq(arr) {
  return [...new Set(arr)];
}

// ---------- Imbasan ----------

async function scan() {
  const st = $('status');
  st.className = 'status';
  st.textContent = 'Mengimbas halaman…';
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    tabId = tab.id;
    if (!/^https?:/.test(tab.url || '')) throw new Error('Buka halaman PBD dahulu (bukan halaman Chrome).');
    const results = await runAll('scan');
    const ok = results.filter((r) => !r.error);
    const rows = sum(ok, 'rowCount');
    const fields = sum(ok, 'fieldCount');
    pageHeaders = uniq(ok.flatMap((r) => r.headers || []));
    fillColSelects();
    if (!fields) {
      const gkRes = (await runAll('gkScan')).filter((r) => r.rows && r.rows.length);
      const nGk = gkRes.reduce((n, r) => n + r.rows.length, 0);
      if (nGk) {
        st.innerHTML = `<b>Halaman Guru Kelas</b>: ${nGk} murid dikesan.<small>Guna tab "G. Kelas".</small>`;
        document.querySelector('.tabs button[data-tab="gk"]').click();
        window.__gkPage = true;
        return;
      }
      st.className = 'status warn';
      st.innerHTML = '<b>Tiada medan TP dikesan.</b><small>Buka halaman pengisian TP (senarai murid dengan pilihan TP 1–6), kemudian tekan ↻.<br>' +
        `Bingkai diimbas: ${results.length}. <a href="#" id="lnkDiag">Salin maklumat diagnostik</a> dan hantar kepada pembangun.</small>`;
      $('lnkDiag').addEventListener('click', copyDiag);
      $('btnBulk').disabled = true;
      return;
    }
    const sample = ok.flatMap((r) => r.sample || []).slice(0, 2).join(', ');
    st.innerHTML = `<b>${rows} murid</b>, ${fields} medan TP dikesan` +
      (pageHeaders.length > 1 ? ` (${pageHeaders.length} kolum)` : '') +
      `<small>Contoh: ${escapeHtml(sample)}</small>`;
    $('btnBulk').disabled = bulkTp === null;
  } catch (e) {
    st.className = 'status err';
    st.innerHTML = 'Ralat: ' + escapeHtml(e.message || e) + ' <a href="#" id="lnkDiag">Salin diagnostik</a>';
    $('lnkDiag').addEventListener('click', copyDiag);
  }
}

async function copyDiag(ev) {
  if (ev) ev.preventDefault();
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    let res;
    try { res = await runAll('diag'); } catch (e) { res = [{ error: String(e.message || e) }]; }
    const txt = JSON.stringify({ version: chrome.runtime.getManifest().version, url: (tab.url || '').split('?')[0], frames: res }, null, 1);
    await navigator.clipboard.writeText(txt);
    alert('Maklumat diagnostik telah disalin (nama & nombor murid disembunyikan). Tampal (Ctrl+V) dalam perbualan dengan pembangun.');
  } catch (e) {
    alert('Gagal menyalin: ' + (e.message || e));
  }
}

function fillColSelects() {
  for (const id of ['importCol', 'bulkCol']) {
    const sel = $(id);
    const prev = sel.value;
    sel.innerHTML = '';
    if (pageHeaders.length > 1) sel.add(new Option('Semua kolum TP', 'all'));
    pageHeaders.forEach((h) => sel.add(new Option(h, h)));
    if (!pageHeaders.length) sel.add(new Option('Semua kolum TP', 'all'));
    if ([...sel.options].some((o) => o.value === prev)) sel.value = prev;
    else sel.selectedIndex = pageHeaders.length > 1 ? 1 : 0;
  }
}

// ---------- Import ----------

const DEFAULT_SCALE = { 6: 85, 5: 70, 4: 55, 3: 40, 2: 20 }; // TP1 = selebihnya (0 ke atas)
let scale = { ...DEFAULT_SCALE };

function tpVal(v) {
  if (v == null || v === '') return null;
  const m = String(v).trim().match(/^(?:TP\s*)?([0-6])(?:\.0+)?$/i);
  return m ? Number(m[1]) : null;
}

function markVal(v) {
  if (v == null) return null;
  const s = String(v).trim().replace(/%$/, '').replace(',', '.').trim();
  if (!/^\d+(\.\d+)?$/.test(s)) return null;
  const n = Number(s);
  return n >= 0 && n <= 100 ? n : null;
}

function markToTp(m) {
  if (m == null) return null;
  for (const tp of [6, 5, 4, 3, 2]) if (m >= scale[tp]) return tp;
  return 1;
}

function normKey(s) {
  return String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
}

// Penghurai TSV/CSV yang menyokong sel berpetik (cth. tajuk "PPT\nOBJ" dari Google Sheets)
function parseDelimited(txt) {
  const sep = txt.includes('\t') ? '\t' : (txt.split('\n')[0].includes(';') ? ';' : ',');
  const rows = [];
  let row = [], cell = '', q = false;
  for (let i = 0; i < txt.length; i++) {
    const ch = txt[i];
    if (q) {
      if (ch === '"') {
        if (txt[i + 1] === '"') { cell += '"'; i++; } else q = false;
      } else cell += ch;
    } else if (ch === '"' && cell === '') q = true;
    else if (ch === sep) { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && txt[i + 1] === '\n') i++;
      row.push(cell); rows.push(row); row = []; cell = '';
    } else cell += ch;
  }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  return rows;
}

function analyseTable(rows) {
  rows = rows.map((r) => (r || []).map((c) => (c == null ? '' : String(c).replace(/\s+/g, ' ').trim())))
    .filter((r) => r.some((c) => c !== ''));
  if (!rows.length) throw new Error('Tiada data.');

  let h = rows.findIndex((r) => r.some((c) => /nama/i.test(c)));
  let header;
  if (h < 0) {
    header = rows[0].map((_, i) => (i === 0 ? 'NAMA' : 'TP' + (i > 1 ? i : '')));
  } else header = rows[h];
  const body = rows.slice(h + 1).filter((r) => r.length > 1);

  const nameCol = header.findIndex((c) => /nama/i.test(c));
  const icCol = header.findIndex((c) => /(k\/?p\b|\bic\b|mykad|kad pengenalan)/i.test(c) && !/nama/i.test(c));
  const kelasCol = header.findIndex((c) => /kelas|class/i.test(c));
  if (nameCol < 0 && icCol < 0) throw new Error('Kolum NAMA tidak dijumpai.');

  const sources = [];
  header.forEach((name, i) => {
    if ([nameCol, icCol, kelasCol].includes(i)) return;
    if (!name || /^(bil\.?|no\.?)$/i.test(name)) return;
    const vals = body.map((r) => r[i]).filter((v) => v !== '' && v != null && !/^(th|-|x|tidak hadir)$/i.test(v));
    if (!vals.length) return;
    const tpGood = vals.filter((v) => tpVal(v) !== null).length / vals.length;
    const mkGood = vals.filter((v) => markVal(v) !== null).length / vals.length;
    if (tpGood >= 0.8) sources.push({ i, name, kind: 'tp' });
    else if (mkGood >= 0.8) sources.push({ i, name, kind: 'mark' });
  });
  if (!sources.length) throw new Error('Tiada kolum TP atau markah dijumpai.');

  const kelasList = kelasCol >= 0 ? uniq(body.map((r) => r[kelasCol]).filter(Boolean)) : [];
  return { header, body, nameCol, icCol, kelasCol, sources, kelasList };
}

function currentRecords() {
  const t = imported;
  const kelas = $('importKelas').value;
  const srcVal = $('importSource').value;
  const rows = t.body.filter((r) => !kelas || t.kelasCol < 0 || r[t.kelasCol] === kelas);
  const base = (r) => ({
    name: t.nameCol >= 0 ? r[t.nameCol] : '',
    ic: t.icCol >= 0 ? String(r[t.icCol]).replace(/\D/g, '') : '',
  });
  const noMark = [];
  let records;

  if (srcVal === '__tpmap') {
    const pageMap = new Map(pageHeaders.map((p) => [normKey(p), p]));
    const cols = t.sources.filter((s) => s.kind === 'tp' && pageMap.has(normKey(s.name)));
    records = rows.map((r) => {
      const rec = { ...base(r), values: {} };
      cols.forEach((c) => { const v = tpVal(r[c.i]); if (v !== null) rec.values[pageMap.get(normKey(c.name))] = v; });
      return rec;
    }).filter((r) => Object.keys(r.values).length);
  } else {
    const src = t.sources[Number(srcVal)];
    records = [];
    rows.forEach((r) => {
      const rec = base(r);
      if (!rec.name && !rec.ic) return;
      if (src.kind === 'tp') rec.tp = tpVal(r[src.i]);
      else { rec.mark = markVal(r[src.i]); rec.tp = markToTp(rec.mark); }
      if (rec.tp == null) noMark.push(rec.name + (r[src.i] ? ' (' + r[src.i] + ')' : ' (kosong)'));
      else records.push(rec);
    });
  }
  return { records, noMark, total: rows.length };
}

function renderPreview() {
  if (!imported) return;
  const src = imported.sources[Number($('importSource').value)];
  $('scaleBox').classList.toggle('hidden', !src || src.kind !== 'mark');
  $('importCol').closest('.field').classList.toggle('hidden', $('importSource').value === '__tpmap');
  const { records, noMark, total } = currentRecords();
  const dist = [1, 2, 3, 4, 5, 6].map((tp) => records.filter((r) => r.tp === tp).length);
  let html = `<b>${records.length} daripada ${total} murid</b> akan diisi.`;
  if (records.length && records[0].tp != null) {
    html += '<div class="dist">' + dist.map((n, k) => `<span>TP${k + 1}<b>${n}</b></span>`).join('') + '</div>';
  }
  if (noMark.length) html += `⚠️ ${noMark.length} tiada markah/TP (tidak diisi):<ul>${noMark.map((n) => '<li>' + escapeHtml(n) + '</li>').join('')}</ul>`;
  $('importPreview').innerHTML = html;
}

function showImport(data) {
  imported = data;
  chrome.storage.local.set({ imported: data });
  $('importInfo').classList.remove('hidden');
  $('importInfo').innerHTML = `<b>${data.body.length} baris</b> dibaca` +
    (data.kelasList.length ? `, ${data.kelasList.length} kelas` : '') + '.';

  const ks = $('importKelas');
  ks.innerHTML = '';
  ks.add(new Option('Semua kelas', ''));
  data.kelasList.forEach((k) => ks.add(new Option(k, k)));
  ks.closest('.field').classList.toggle('hidden', !data.kelasList.length);

  const ss = $('importSource');
  ss.innerHTML = '';
  const pageKeys = new Set(pageHeaders.map(normKey));
  const mappable = data.sources.filter((s) => s.kind === 'tp' && pageKeys.has(normKey(s.name)));
  if (mappable.length) ss.add(new Option(`TP ikut tajuk kolum (${mappable.length} kolum sepadan)`, '__tpmap'));
  data.sources.forEach((s, k) => ss.add(new Option((s.kind === 'mark' ? 'Markah: ' : 'TP: ') + s.name, String(k))));
  // lalai: kolum TP sepadan, atau kolum markah terakhir yang ada '%'
  if (!mappable.length) {
    const pct = [...data.sources.keys()].filter((k) => data.sources[k].kind === 'mark' && /%/.test(data.sources[k].name));
    const tpc = [...data.sources.keys()].filter((k) => data.sources[k].kind === 'tp');
    ss.value = String(tpc.length ? tpc[0] : (pct.length ? pct[pct.length - 1] : 0));
  }
  $('importOpts').classList.remove('hidden');
  renderPreview();
}

function importError(msg) {
  const info = $('importInfo');
  info.classList.remove('hidden');
  info.innerHTML = '<span style="color:var(--red)">' + escapeHtml(msg) + '</span>';
  $('importOpts').classList.add('hidden');
}

function loadScaleInputs() {
  document.querySelectorAll('#scaleBox input[data-tp]').forEach((inp) => { inp.value = scale[inp.dataset.tp]; });
}

$('scaleBox').addEventListener('input', (ev) => {
  const inp = ev.target.closest('input[data-tp]');
  if (!inp) return;
  const v = Number(inp.value);
  if (!Number.isFinite(v)) return;
  scale[inp.dataset.tp] = v;
  chrome.storage.local.set({ scale });
  renderPreview();
});

$('btnScaleReset').addEventListener('click', () => {
  scale = { ...DEFAULT_SCALE };
  chrome.storage.local.set({ scale });
  loadScaleInputs();
  renderPreview();
});

$('importKelas').addEventListener('change', () => { chrome.storage.local.set({ kelas: $('importKelas').value }); renderPreview(); });
$('importSource').addEventListener('change', () => { chrome.storage.local.set({ source: $('importSource').value }); renderPreview(); });

$('fileInput').addEventListener('change', async (ev) => {
  const f = ev.target.files[0];
  if (!f) return;
  try {
    const buf = await f.arrayBuffer();
    const wb = XLSX.read(buf, { type: 'array' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false, defval: '' });
    showImport(analyseTable(rows));
  } catch (e) {
    importError('Gagal baca fail: ' + (e.message || e));
  }
  ev.target.value = '';
});

$('btnParse').addEventListener('click', () => {
  const txt = $('pasteBox').value;
  if (!txt.trim()) return importError('Tampal data dahulu.');
  try {
    showImport(analyseTable(parseDelimited(txt)));
  } catch (e) {
    importError(e.message || String(e));
  }
});

$('btnFill').addEventListener('click', async () => {
  if (!imported) return;
  const out = $('importResult');
  out.className = 'result';
  out.textContent = 'Mengisi…';
  try {
    const { records } = currentRecords();
    if (!records.length) throw new Error('Tiada rekod untuk diisi.');
    const res = (await runAll('fill', {
      records,
      col: $('importCol').value || 'all',
      onlyEmpty: $('impOnlyEmpty').checked,
      byOrder: $('impByOrder').checked,
    })).filter((r) => !r.error && r.rows);
    if (!res.length) throw new Error('Tiada medan TP di halaman ini.');
    const filled = sum(res, 'filled');
    const skipped = sum(res, 'skipped');
    const unmatched = res.flatMap((r) => r.unmatchedRows || []);
    const unused = res.length === 1 ? res[0].unusedRecords : [];
    let html = `<b>✅ ${filled} medan diisi</b>` + (skipped ? `, ${skipped} dilangkau (sudah ada nilai)` : '') + '.';
    if (unmatched.length) html += `<br>⚠️ ${unmatched.length} murid di halaman tiada padanan (ditanda merah):<ul>${unmatched.map((n) => '<li>' + escapeHtml(n) + '</li>').join('')}</ul>`;
    if (unused && unused.length) html += `<br>ℹ️ ${unused.length} rekod fail tidak digunakan:<ul>${unused.map((n) => '<li>' + escapeHtml(n) + '</li>').join('')}</ul>`;
    html += '<br>Semak, kemudian tekan <b>Simpan</b> dalam sistem PBD.';
    out.className = 'result ok';
    out.innerHTML = html;
  } catch (e) {
    out.className = 'result err';
    out.textContent = 'Ralat: ' + (e.message || e);
  }
});

// ---------- Pukal ----------

$('tpGrid').addEventListener('click', (ev) => {
  const b = ev.target.closest('button');
  if (!b) return;
  bulkTp = Number(b.dataset.tp);
  document.querySelectorAll('#tpGrid button').forEach((x) => x.classList.toggle('sel', x === b));
  $('btnBulk').disabled = false;
  $('btnBulk').textContent = `Isi TP ${bulkTp} secara pukal`;
});

$('btnBulk').addEventListener('click', async () => {
  const out = $('bulkResult');
  out.className = 'result';
  out.textContent = 'Mengisi…';
  try {
    const onlyPicked = $('bulkOnlyPicked').checked;
    const res = (await runAll('bulk', {
      tp: bulkTp,
      col: $('bulkCol').value || 'all',
      onlyEmpty: $('bulkOnlyEmpty').checked,
      onlyPicked,
    })).filter((r) => !r.error);
    const filled = sum(res, 'filled');
    const skipped = sum(res, 'skipped');
    out.className = 'result ok';
    out.innerHTML = `<b>✅ ${filled} medan diisi dengan TP ${bulkTp}</b>` +
      (skipped ? `, ${skipped} dilangkau` : '') + '.' +
      (onlyPicked && !filled ? '<br>Tiada baris ditanda. Hidupkan "Tunjuk medan TP", tanda baris di halaman, kemudian buka semula popup.' : '');
  } catch (e) {
    out.className = 'result err';
    out.textContent = 'Ralat: ' + (e.message || e);
  }
});

// ---------- Ulasan & Usaha ----------

const KATS = ['CEMERLANG', 'SEDERHANA', 'LEMAH'];
const USAHA = ['SANGAT TINGGI', 'TINGGI', 'SEDERHANA', 'RENDAH'];
const DEFAULT_KATMAP = { 1: 'LEMAH', 2: 'LEMAH', 3: 'SEDERHANA', 4: 'SEDERHANA', 5: 'CEMERLANG', 6: 'CEMERLANG' };
const DEFAULT_USAHAMAP = { 1: 'RENDAH', 2: 'RENDAH', 3: 'SEDERHANA', 4: 'SEDERHANA', 5: 'TINGGI', 6: 'SANGAT TINGGI' };
let katMap = { ...DEFAULT_KATMAP };
let usahaMap = { ...DEFAULT_USAHAMAP };

function renderMap(boxId, options, map) {
  const box = $(boxId);
  box.innerHTML = '';
  for (let tp = 1; tp <= 6; tp++) {
    const lab = document.createElement('label');
    lab.textContent = 'TP' + tp;
    const sel = document.createElement('select');
    options.forEach((k) => sel.add(new Option(k, k)));
    sel.value = map[tp];
    sel.addEventListener('change', () => { map[tp] = sel.value; saveUlasanSettings(); });
    lab.appendChild(sel);
    box.appendChild(lab);
  }
}

function syncSections() {
  $('ulasanBox').classList.toggle('dim', !$('ulDoUlasan').checked);
  $('usahaBox').classList.toggle('dim', !$('ulDoUsaha').checked);
}

function saveUlasanSettings() {
  syncSections();
  chrome.storage.local.set({ ulasan: {
    katMap, usahaMap,
    picks: { C: $('pickC').value, S: $('pickS').value, L: $('pickL').value },
    doUlasan: $('ulDoUlasan').checked, doUsaha: $('ulDoUsaha').checked,
  } });
}
['pickC', 'pickS', 'pickL'].forEach((id) => $(id).addEventListener('input', saveUlasanSettings));
['ulDoUlasan', 'ulDoUsaha'].forEach((id) => $(id).addEventListener('change', saveUlasanSettings));

async function startUlasan(limit) {
  if (!licRequire()) return;
  const out = $('ulResult');
  out.className = 'result';
  out.textContent = 'Memulakan…';
  try {
    const doUlasan = $('ulDoUlasan').checked, doUsaha = $('ulDoUsaha').checked;
    if (!doUlasan && !doUsaha) throw new Error('Tandakan Ulasan Guru dan/atau Usaha Murid.');
    const res = (await runAll('ulasan', {
      map: katMap,
      picks: { CEMERLANG: $('pickC').value, SEDERHANA: $('pickS').value, LEMAH: $('pickL').value },
      doUlasan, doUsahaCol: doUsaha, usahaMap,
      onlyPicked: $('ulOnlyPicked').checked,
      limit,
      delay: doUlasan ? 400 : 150,
    }));
    const err = res.find((r) => r.error);
    if (err) throw new Error(err.error);
    if (!res.some((r) => r.started)) throw new Error('Tiada murid di halaman ini.');
    out.className = 'result ok';
    out.innerHTML = '▶ Sedang berjalan di halaman. Lihat kotak kemajuan di penjuru kanan bawah. <b>Jangan klik halaman semasa proses.</b>';
    if (!limit) setTimeout(() => window.close(), 1200);
  } catch (e) {
    out.className = 'result err';
    out.textContent = 'Ralat: ' + (e.message || e);
  }
}
$('btnUlTest').addEventListener('click', () => startUlasan(1));
$('btnUlAll').addEventListener('click', () => {
  if (confirm('Isi untuk semua murid yang ada TP? Tetingkap ulasan setiap murid akan dibuka dan disimpan secara automatik.')) startUlasan(0);
});

// ---------- Guru Kelas ----------

let gk = { students: [], texts: {}, seed: 0 };

function gkSubjectNames() {
  return gkParseSubjects($('gkSubjects').value);
}

function gkSave() {
  chrome.storage.local.set({ gk, gkSubjects: $('gkSubjects').value, gkUseName: $('gkUseName').checked });
}

function gkKey(s) { return s.ic || s.name; }

function gkRender() {
  const box = $('gkList');
  box.innerHTML = '';
  gk.students.forEach((s, i) => {
    const d = document.createElement('div');
    d.className = 'gkitem';
    const tps = Object.entries(s.subjects).map(([k, v]) => `${k} ${v}`).join(' · ');
    const t = gk.texts[gkKey(s)] || '';
    d.innerHTML = `<div class="nm"><span>${i + 1}. ${escapeHtml(s.name)}</span><small class="len">${t.length} aks.</small></div><div class="tps">${escapeHtml(tps)}</div>`;
    const ta = document.createElement('textarea');
    ta.value = t;
    ta.addEventListener('input', () => {
      gk.texts[gkKey(s)] = ta.value;
      d.querySelector('.len').textContent = ta.value.length + ' aks.';
      gkSave();
    });
    d.appendChild(ta);
    box.appendChild(d);
  });
  const has = gk.students.length > 0;
  $('gkActions').classList.toggle('hidden', !has);
  $('btnGkRegen').disabled = !has;
}

function gkGenerateAll() {
  const opts = { subjectNames: gkSubjectNames(), useName: $('gkUseName').checked, seed: gk.seed };
  gk.texts = {};
  gk.students.forEach((s) => { gk.texts[gkKey(s)] = gkGenerate(s, opts); });
  gkSave();
  gkRender();
}

$('btnGkGen').addEventListener('click', async () => {
  if (!licRequire()) return;
  const info = $('gkInfo');
  info.textContent = 'Membaca halaman…';
  try {
    const res = (await runAll('gkScan')).filter((r) => r.rows && r.rows.length);
    const rows = res.flatMap((r) => r.rows);
    if (!rows.length) throw new Error('Tiada jadual Ulasan Guru Kelas di halaman ini. Buka halaman PBD Guru Kelas, kemudian cuba lagi.');
    gk.students = rows;
    const subj = new Set(rows.flatMap((r) => Object.keys(r.subjects)));
    const names = gkSubjectNames();
    const unknown = [...subj].filter((c) => !names[c]);
    info.innerHTML = `<b>${rows.length} murid</b>, ${subj.size} mata pelajaran dikesan.` +
      (unknown.length ? `<br>⚠️ Kod tanpa nama penuh: ${escapeHtml(unknown.join(', '))} (tambah dalam "Nama mata pelajaran").` : '');
    gkGenerateAll();
  } catch (e) {
    info.innerHTML = '<span style="color:var(--red)">' + escapeHtml(e.message || e) + '</span>';
  }
});

$('btnGkRegen').addEventListener('click', () => {
  if (!confirm('Jana semula semua ulasan dengan ayat berbeza? Suntingan manual akan hilang.')) return;
  gk.seed = (gk.seed || 0) + 1;
  gkGenerateAll();
});

$('gkUseName').addEventListener('change', gkSave);
$('gkSubjects').addEventListener('input', gkSave);

$('btnGkCopy').addEventListener('click', async () => {
  const lines = gk.students.map((s, i) => [i + 1, s.name, s.ic, (gk.texts[gkKey(s)] || '').replace(/\s+/g, ' ')].join('\t'));
  await navigator.clipboard.writeText(['BIL\tNAMA\tID PENGENALAN\tULASAN GURU KELAS', ...lines].join('\n'));
  $('gkResult').className = 'result ok';
  $('gkResult').textContent = 'Disalin. Tampal (Ctrl+V) dalam Excel / Google Sheets.';
});

async function gkStart(limit) {
  if (!licRequire()) return;
  const out = $('gkResult');
  out.className = 'result';
  out.textContent = 'Memulakan…';
  try {
    const items = gk.students.map((s) => ({ name: s.name, ic: s.ic, text: (gk.texts[gkKey(s)] || '').trim() }))
      .filter((it) => it.text);
    if (!items.length) throw new Error('Tiada ulasan untuk diisi.');
    const res = await runAll('gkFill', { items, limit, skipExisting: $('gkSkip').checked });
    const err = res.find((r) => r.error);
    if (err) throw new Error(err.error);
    if (!res.some((r) => r.started)) throw new Error('Jadual Guru Kelas tidak dijumpai di halaman ini.');
    out.className = 'result ok';
    out.innerHTML = '▶ Sedang berjalan di halaman. Lihat kotak kemajuan di penjuru kanan bawah. <b>Jangan klik halaman semasa proses.</b>';
    if (!limit) setTimeout(() => window.close(), 1200);
  } catch (e) {
    out.className = 'result err';
    out.textContent = 'Ralat: ' + (e.message || e);
  }
}
$('btnGkTest').addEventListener('click', () => gkStart(1));
$('btnGkAll').addEventListener('click', () => {
  if (confirm(`Isi Ulasan Guru Kelas untuk ${gk.students.length} murid?`)) gkStart(0);
});

// ---------- Eksport ----------

async function getExport() {
  const res = (await runAll('export')).filter((r) => !r.error && r.rows && r.rows.length);
  if (!res.length) throw new Error('Tiada data TP di halaman ini.');
  const headers = uniq(res.flatMap((r) => r.headers));
  const rows = res.flatMap((r) => r.rows);
  const hasIc = rows.some((r) => r.ic);
  const aoa = [['BIL', 'NAMA', ...(hasIc ? ['NO KP'] : []), ...headers]];
  rows.forEach((r, i) => {
    aoa.push([i + 1, r.name, ...(hasIc ? [r.ic] : []), ...headers.map((h) => (r.values[h] == null ? '' : r.values[h]))]);
  });
  return aoa;
}

function fileBase() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `PBD_TP_${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
}

async function doExport(kind) {
  const out = $('exportResult');
  out.className = 'result';
  out.textContent = 'Mengeksport…';
  try {
    const aoa = await getExport();
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    if (kind === 'xlsx') {
      ws['!cols'] = aoa[0].map((h, i) => ({ wch: i === 1 ? 40 : Math.max(8, String(h).length + 2) }));
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'TP');
      XLSX.writeFile(wb, fileBase() + '.xlsx');
    } else {
      const csv = '﻿' + XLSX.utils.sheet_to_csv(ws);
      const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = fileBase() + '.csv';
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    }
    out.className = 'result ok';
    out.innerHTML = `<b>✅ ${aoa.length - 1} murid dieksport.</b>`;
  } catch (e) {
    out.className = 'result err';
    out.textContent = 'Ralat: ' + (e.message || e);
  }
}

$('btnExportXlsx').addEventListener('click', () => doExport('xlsx'));
$('btnExportCsv').addEventListener('click', () => doExport('csv'));

// ---------- UI umum ----------

document.querySelectorAll('.tabs button').forEach((b) => {
  b.addEventListener('click', () => {
    document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('active', x === b));
    document.querySelectorAll('.panel').forEach((p) => p.classList.toggle('active', p.id === 'tab-' + b.dataset.tab));
    chrome.storage.local.set({ tab: b.dataset.tab });
  });
});

$('chkHighlight').addEventListener('change', async (ev) => {
  chrome.storage.local.set({ highlight: ev.target.checked });
  try { await runAll('highlight', { on: ev.target.checked }); } catch (e) { /* abaikan */ }
});

$('btnRescan').addEventListener('click', scan);
$('btnFloat').addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!/^https:\/\/[^/]*\.(moe\.gov\.my|moe-dl\.edu\.my)\//.test(tab.url || '')) {
      $('status').className = 'status warn';
      $('status').textContent = 'Panel terapung hanya untuk halaman SPPB / PBD (moe.gov.my).';
      return;
    }
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['floating.js'] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => window.__pbdxFloatOpen && window.__pbdxFloatOpen() });
    window.close();
  } catch (e) {
    $('status').className = 'status err';
    $('status').textContent = 'Gagal buka panel: ' + (e.message || e);
  }
});
$('lnkDiagFoot').addEventListener('click', copyDiag);

function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

(async function init() {
  const saved = await chrome.storage.local.get(['imported', 'tab', 'highlight', 'scale', 'kelas', 'source', 'ulasan', 'gk', 'gkSubjects', 'gkUseName']);
  $('gkSubjects').value = saved.gkSubjects || GK_DEFAULT_SUBJECTS;
  if (saved.gkUseName === false) $('gkUseName').checked = false;
  if (saved.gk && saved.gk.students) { gk = saved.gk; gkRender(); $('gkInfo').innerHTML = `<b>${gk.students.length} murid</b> (ulasan tersimpan).`; }
  if (saved.ulasan) {
    const u = saved.ulasan;
    katMap = { ...DEFAULT_KATMAP, ...u.katMap };
    usahaMap = { ...DEFAULT_USAHAMAP, ...u.usahaMap };
    const pk = u.picks || {};
    // nilai lama "1" (lalai v1.4) ditukar kepada rawak
    const fix = (v) => (v == null || v === '1' ? 'rawak' : v);
    $('pickC').value = fix(pk.C); $('pickS').value = fix(pk.S); $('pickL').value = fix(pk.L);
    if (u.doUlasan === false) $('ulDoUlasan').checked = false;
    if (u.doUsaha === false) $('ulDoUsaha').checked = false;
  }
  renderMap('katMap', KATS, katMap);
  renderMap('usahaMap', USAHA, usahaMap);
  syncSections();
  if (saved.scale) scale = { ...DEFAULT_SCALE, ...saved.scale };
  loadScaleInputs();
  fillColSelects();
  await scan();
  if (saved.tab && !window.__gkPage) {
    const b = document.querySelector(`.tabs button[data-tab="${saved.tab}"]`);
    if (b) b.click();
  }
  if (saved.highlight) $('chkHighlight').checked = true;
  if (saved.imported && saved.imported.body) {
    showImport(saved.imported);
    if (saved.kelas != null && [...$('importKelas').options].some((o) => o.value === saved.kelas)) $('importKelas').value = saved.kelas;
    if (saved.source != null && [...$('importSource').options].some((o) => o.value === saved.source)) $('importSource').value = saved.source;
    renderPreview();
  }
})();
