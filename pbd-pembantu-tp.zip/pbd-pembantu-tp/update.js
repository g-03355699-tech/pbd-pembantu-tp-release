/* PBD Pembantu TP — semakan versi baharu
 * Membaca latest.json dari repo awam pbd-pembantu-tp-release.
 * Tiada kod dimuat turun atau dijalankan; hanya nombor versi dan pautan.
 */
'use strict';

const UPDATE_URL = 'https://raw.githubusercontent.com/g-03355699-tech/pbd-pembantu-tp-release/main/latest.json';
const UPDATE_PAGE = 'https://github.com/g-03355699-tech/pbd-pembantu-tp-release';
const CHECK_EVERY_MS = 6 * 60 * 60 * 1000; // 6 jam

function cmpVer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d;
  }
  return 0;
}

function upEsc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function showUpdate(info) {
  const cur = chrome.runtime.getManifest().version;
  const box = document.getElementById('updateBanner');
  if (!info || !info.version || cmpVer(info.version, cur) <= 0) {
    box.classList.add('hidden');
    return false;
  }
  const notes = Array.isArray(info.notes) ? info.notes : (info.notes ? [info.notes] : []);
  box.innerHTML = `<b>🔔 Versi ${upEsc(info.version)} tersedia</b> (anda: ${upEsc(cur)})` +
    (notes.length ? '<ul>' + notes.slice(0, 5).map((n) => '<li>' + upEsc(n) + '</li>').join('') + '</ul>' : '') +
    '<button id="btnUpdate" type="button">Muat turun versi baharu</button>' +
    '<ol><li>Unzip dan gantikan fail dalam folder extension lama.</li>' +
    '<li>Buka <b>chrome://extensions</b> → tekan ↻ Reload.</li><li>Tekan F5 pada halaman PBD.</li></ol>';
  box.classList.remove('hidden');
  document.getElementById('btnUpdate').addEventListener('click', () => {
    const url = /^https:\/\/(github\.com|raw\.githubusercontent\.com|objects\.githubusercontent\.com)\//.test(info.zip || '') ? info.zip : UPDATE_PAGE;
    chrome.tabs.create({ url });
  });
  return true;
}

async function checkUpdate(force) {
  const now = Date.now();
  const st = await chrome.storage.local.get(['updLast', 'updInfo']);
  if (!force && st.updInfo && st.updLast && now - st.updLast < CHECK_EVERY_MS) {
    return showUpdate(st.updInfo) ? 'baharu' : 'terkini';
  }
  const res = await fetch(UPDATE_URL + '?t=' + now, { cache: 'no-store' });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const info = await res.json();
  await chrome.storage.local.set({ updLast: now, updInfo: info });
  return showUpdate(info) ? 'baharu' : 'terkini';
}

document.addEventListener('DOMContentLoaded', () => {
  const v = chrome.runtime.getManifest().version;
  document.getElementById('verLabel').textContent = 'v' + v;
  checkUpdate(false).catch(() => { /* senyap jika tiada internet */ });
  document.getElementById('lnkUpdate').addEventListener('click', async (ev) => {
    ev.preventDefault();
    const a = ev.target;
    a.textContent = 'Menyemak…';
    try {
      const r = await checkUpdate(true);
      a.textContent = r === 'baharu' ? 'Versi baharu tersedia ↑' : 'Sudah versi terkini ✓';
    } catch (e) {
      a.textContent = 'Gagal semak (' + (e.message || e) + ')';
    }
  });
});
