/*
 * PBD Pembantu TP — panel terapung
 * Memaparkan popup extension sebagai panel boleh-seret di atas halaman PBD.
 * Dimuatkan secara automatik pada halaman *.moe.gov.my (untuk buka semula selepas F5)
 * dan juga disuntik apabila butang 📌 ditekan dalam popup.
 */
(function () {
  if (window.top !== window) return; // hanya bingkai utama
  if (window.__pbdxFloatOpen) return; // sudah dimuatkan
  const HOST_ID = 'pbdx-float-host';

  async function getState() {
    try { return (await chrome.storage.local.get('floatState')).floatState || {}; } catch (e) { return {}; }
  }
  function setState(patch) {
    getState().then((s) => chrome.storage.local.set({ floatState: { ...s, ...patch } })).catch(() => {});
  }

  function clampPos(x, y, w) {
    const maxX = Math.max(0, window.innerWidth - Math.min(w, window.innerWidth) - 4);
    const maxY = Math.max(0, window.innerHeight - 44);
    return { x: Math.min(Math.max(0, x), maxX), y: Math.min(Math.max(0, y), maxY) };
  }

  async function open() {
    let host = document.getElementById(HOST_ID);
    if (host) { host.style.display = ''; host.__pbdxFocus && host.__pbdxFocus(); return; }
    const st = await getState();
    const W = 384;
    const H = Math.min(st.h || 640, window.innerHeight - 20);
    const pos = clampPos(st.x != null ? st.x : window.innerWidth - W - 16, st.y != null ? st.y : 70, W);

    host = document.createElement('div');
    host.id = HOST_ID;
    host.style.cssText = `position:fixed;left:${pos.x}px;top:${pos.y}px;z-index:2147483646;`;
    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `
      <style>
        .box { width:${W}px; background:#fff; border:2px solid #0e7c66; border-radius:10px; box-shadow:0 8px 30px rgba(0,0,0,.28); overflow:hidden; display:flex; flex-direction:column; font:13px "Segoe UI",system-ui,sans-serif; }
        .bar { display:flex; align-items:center; gap:6px; background:#0e7c66; color:#fff; padding:6px 8px; cursor:move; user-select:none; touch-action:none; }
        .bar b { flex:1; font-size:13px; }
        .bar button { all:unset; cursor:pointer; width:24px; height:22px; text-align:center; border-radius:4px; font-size:14px; line-height:22px; }
        .bar button:hover { background:rgba(255,255,255,.2); }
        iframe { border:0; width:100%; height:${H}px; display:block; background:#fff; }
        .min iframe, .min .grip { display:none; }
        .shield { position:absolute; inset:34px 0 0 0; display:none; }
        .dragging .shield { display:block; }
        .grip { height:10px; cursor:ns-resize; background:linear-gradient(#fff,#e3f4ef); border-top:1px solid #d6e0dd; }
        .grip::after { content:""; display:block; width:40px; height:3px; margin:3px auto 0; border-radius:2px; background:#9fb8b1; }
      </style>
      <div class="box ${st.min ? 'min' : ''}">
        <div class="bar" title="Seret untuk alih">
          <b>📋 PBD Pembantu TP</b>
          <button class="bmin" title="Kecilkan / besarkan">${st.min ? '▢' : '—'}</button>
          <button class="bx" title="Tutup panel">✕</button>
        </div>
        <iframe src="${chrome.runtime.getURL('popup.html?float=1')}" allow="clipboard-write"></iframe>
        <div class="grip" title="Seret untuk ubah tinggi"></div>
        <div class="shield"></div>
      </div>`;
    document.documentElement.appendChild(host);

    const box = root.querySelector('.box');
    const bar = root.querySelector('.bar');
    const frame = root.querySelector('iframe');

    // seret
    bar.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button')) return;
      const sx = e.clientX, sy = e.clientY;
      const ox = host.offsetLeft, oy = host.offsetTop;
      box.classList.add('dragging');
      bar.setPointerCapture(e.pointerId);
      const move = (ev) => {
        const p = clampPos(ox + ev.clientX - sx, oy + ev.clientY - sy, W);
        host.style.left = p.x + 'px';
        host.style.top = p.y + 'px';
      };
      const up = () => {
        box.classList.remove('dragging');
        bar.removeEventListener('pointermove', move);
        bar.removeEventListener('pointerup', up);
        setState({ x: host.offsetLeft, y: host.offsetTop });
      };
      bar.addEventListener('pointermove', move);
      bar.addEventListener('pointerup', up);
    });

    // ubah tinggi
    const grip = root.querySelector('.grip');
    grip.addEventListener('pointerdown', (e) => {
      const sy = e.clientY, oh = frame.offsetHeight;
      box.classList.add('dragging');
      grip.setPointerCapture(e.pointerId);
      const move = (ev) => { frame.style.height = Math.max(200, Math.min(window.innerHeight - 60, oh + ev.clientY - sy)) + 'px'; };
      const up = () => {
        box.classList.remove('dragging');
        grip.removeEventListener('pointermove', move);
        grip.removeEventListener('pointerup', up);
        setState({ h: frame.offsetHeight });
      };
      grip.addEventListener('pointermove', move);
      grip.addEventListener('pointerup', up);
    });

    root.querySelector('.bmin').addEventListener('click', (e) => {
      const min = box.classList.toggle('min');
      e.target.textContent = min ? '▢' : '—';
      setState({ min });
    });
    root.querySelector('.bx').addEventListener('click', () => {
      host.remove();
      setState({ open: false });
    });
    host.__pbdxFocus = () => { box.classList.remove('min'); root.querySelector('.bmin').textContent = '—'; setState({ min: false }); };

    window.addEventListener('resize', () => {
      const p = clampPos(host.offsetLeft, host.offsetTop, W);
      host.style.left = p.x + 'px';
      host.style.top = p.y + 'px';
    });
    setState({ open: true });
  }

  window.__pbdxFloatOpen = open;

  // dibuka semula secara automatik selepas muat semula halaman
  getState().then((s) => { if (s.open) open(); });
})();
