/*
 * PBD Pembantu TP — langganan (luar talian)
 * Kod langganan = PBD1.<payload base64url>.<tandatangan ECDSA P-256 base64url>
 * payload: { v, n: nama, e: emel, d: kod peranti, x: tarikh tamat YYYY-MM-DD, i: tarikh keluar }
 * Hanya kunci AWAM ada di sini. Kunci rahsia disimpan oleh pembangun sahaja.
 */
'use strict';

const LIC_PUBLIC_JWK = {
  kty: 'EC', crv: 'P-256',
  x: 'uCjizs11_qkuDBhJ8GC3jJiMBv4qPdyBScT-BbMzBUE',
  y: 'MYvU7-vTRuJTsypCnDlTU3ktKLI9hheKcBeOeP2B8PA',
};
const LIC_CONTACT = 'Hubungi pembangun (Cikgu Ibrahim, SM Sains Kuala Selangor) dan berikan Kod Peranti di atas.';
const LIC_PHONE = '0193002591';
const LIC_WA = '60193002591';
const LIC_EMAIL = 'ibrahim.kadri@kusess.edu.my';

function licContactMsg(dev, renew) {
  return (renew ? 'Salam Cikgu Ibrahim, saya ingin MEMPERBAHARUI langganan PBD Pembantu TP.' : 'Salam Cikgu Ibrahim, saya ingin MELANGGAN PBD Pembantu TP.') +
    '\n\nNama: \nSekolah: \nKod Peranti: ' + dev + '\n\nTerima kasih.';
}

function licOpenUrl(url) {
  try { chrome.tabs.create({ url }); } catch (e) { window.open(url, '_blank'); }
}

function licContactHtml() {
  return `<div class="contact">
      <button type="button" class="wa" data-act="wa">💬 WhatsApp</button>
      <button type="button" class="em" data-act="email">✉️ Emel</button>
    </div>
    <p class="hint small contact-txt">📞 ${LIC_PHONE.replace(/^(\d{3})(\d{3})(\d+)$/, '$1-$2 $3')} · ${LIC_EMAIL}</p>`;
}

function licBindContact(root, renew) {
  root.querySelectorAll('[data-act]').forEach((b) => b.addEventListener('click', async () => {
    const dev = await licDeviceId();
    const msg = licContactMsg(dev, renew);
    if (b.dataset.act === 'wa') licOpenUrl('https://wa.me/' + LIC_WA + '?text=' + encodeURIComponent(msg));
    else licOpenUrl('mailto:' + LIC_EMAIL + '?subject=' + encodeURIComponent((renew ? 'Pembaharuan' : 'Langganan') + ' PBD Pembantu TP — ' + dev) + '&body=' + encodeURIComponent(msg));
  }));
}
const LIC_PREMIUM_TABS = ['ulasan', 'gk'];
const LIC_WARN_DAYS = 14;

function b64urlToBytes(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
}

async function licDeviceId() {
  const st = await chrome.storage.local.get('deviceId');
  if (st.deviceId) return st.deviceId;
  const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const b = crypto.getRandomValues(new Uint8Array(12));
  const raw = [...b].map((x) => abc[x % abc.length]).join('');
  const id = raw.match(/.{4}/g).join('-');
  await chrome.storage.local.set({ deviceId: id });
  return id;
}

function licToday() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function licDaysLeft(exp) {
  const a = new Date(licToday() + 'T00:00:00'), b = new Date(exp + 'T00:00:00');
  return Math.round((b - a) / 86400000);
}

// Pulangkan { ok, reason, payload, daysLeft }
async function licVerify(code, deviceId) {
  code = String(code || '').replace(/\s+/g, '');
  const parts = code.split('.');
  if (parts.length !== 3 || parts[0] !== 'PBD1') return { ok: false, reason: 'Format kod tidak sah.' };
  let payload;
  try {
    payload = JSON.parse(new TextDecoder().decode(b64urlToBytes(parts[1])));
  } catch (e) {
    return { ok: false, reason: 'Kod rosak atau tidak lengkap.' };
  }
  try {
    const key = await crypto.subtle.importKey('jwk', LIC_PUBLIC_JWK, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    const good = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key,
      b64urlToBytes(parts[2]), new TextEncoder().encode(parts[0] + '.' + parts[1]));
    if (!good) return { ok: false, reason: 'Kod tidak sah (tandatangan salah).' };
  } catch (e) {
    return { ok: false, reason: 'Kod tidak sah.' };
  }
  if (payload.d !== deviceId) return { ok: false, reason: 'Kod ini untuk komputer lain (Kod Peranti tidak sepadan).', payload };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(payload.x || '')) return { ok: false, reason: 'Tarikh tamat tidak sah.', payload };
  const daysLeft = licDaysLeft(payload.x);
  if (daysLeft < 0) return { ok: false, reason: 'Langganan telah tamat pada ' + payload.x + '.', payload, daysLeft, expired: true };
  return { ok: true, payload, daysLeft };
}

// ---------- UI ----------

const lic = { ok: false, info: null };

function licLifetime(iso) { return String(iso) >= '2099-12-31'; }

function licEsc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function licFmtDate(iso) {
  if (licLifetime(iso)) return 'Seumur hidup';
  const [y, m, d] = iso.split('-');
  const bln = ['Jan', 'Feb', 'Mac', 'Apr', 'Mei', 'Jun', 'Jul', 'Ogo', 'Sep', 'Okt', 'Nov', 'Dis'];
  return `${+d} ${bln[+m - 1]} ${y}`;
}

function licApplyLocks() {
  LIC_PREMIUM_TABS.forEach((t) => {
    const btn = document.querySelector(`.tabs button[data-tab="${t}"]`);
    const panel = document.getElementById('tab-' + t);
    if (!btn || !panel) return;
    btn.classList.toggle('locked', !lic.ok);
    let lock = panel.querySelector('.lockbox');
    if (!lic.ok) {
      if (!lock) {
        lock = document.createElement('div');
        lock.className = 'lockbox';
        lock.innerHTML = '<div class="lk-ico">🔒</div><b>Fungsi langganan</b><p>' +
          (t === 'gk' ? 'Ulasan Guru Kelas automatik' : 'Ulasan Guru dan Usaha Murid automatik') +
          ' memerlukan kod langganan.</p><button type="button" class="primary lk-open">Masukkan kod langganan</button>' +
          '<p class="hint small" style="margin-top:12px">Belum ada kod? Hubungi pembangun:</p>' + licContactHtml();
        panel.prepend(lock);
        licBindContact(lock, false);
        lock.querySelector('.lk-open').addEventListener('click', () => licOpenPanel(true));
      }
      panel.classList.add('is-locked');
    } else {
      if (lock) lock.remove();
      panel.classList.remove('is-locked');
    }
  });
  const foot = document.getElementById('licFoot');
  if (foot) {
    if (lic.ok) {
      const p = lic.info.payload;
      const warn = lic.info.daysLeft <= LIC_WARN_DAYS;
      foot.innerHTML = `<a href="#" id="lnkLic" class="${warn ? 'warn' : ''}">✓ Langganan: ${licEsc(p.n || 'aktif')} · ${licLifetime(p.x) ? '♾ seumur hidup' : 'hingga ' + licFmtDate(p.x)}` +
        (warn ? ` (${lic.info.daysLeft} hari lagi)` : '') + '</a>';
    } else {
      foot.innerHTML = '<a href="#" id="lnkLic">🔒 Versi percuma · Langgan</a>';
    }
    document.getElementById('lnkLic').addEventListener('click', (ev) => { ev.preventDefault(); licOpenPanel(); });
  }
}

async function licOpenPanel(focus) {
  const box = document.getElementById('licPanel');
  const dev = await licDeviceId();
  const st = await chrome.storage.local.get('licCode');
  let statusHtml = '';
  if (lic.ok) {
    const p = lic.info.payload;
    statusHtml = `<div class="lic-ok">✅ <b>Langganan aktif</b><br>${licEsc(p.n || '')}${p.e ? ' · ' + licEsc(p.e) : ''}<br>${licLifetime(p.x) ? '<b>♾ Seumur hidup</b>' : `Sah hingga <b>${licFmtDate(p.x)}</b> (${lic.info.daysLeft} hari lagi)`}</div>`;
  } else if (lic.info && st.licCode) {
    statusHtml = `<div class="lic-bad">⚠️ ${licEsc(lic.info.reason)}</div>`;
  }
  box.innerHTML = `
    <div class="lic-head"><b>Langganan PBD Pembantu TP</b><button type="button" class="lic-x" title="Tutup">×</button></div>
    ${statusHtml}
    <p class="label">Kod Peranti komputer ini</p>
    <div class="devid"><code id="devId">${licEsc(dev)}</code><button type="button" id="btnCopyDev" class="secondary">Salin</button></div>
    <p class="hint small">${lic.ok ? 'Untuk pembaharuan, hubungi pembangun:' : 'Untuk melanggan, hantar Kod Peranti ini kepada pembangun:'}</p>
    ${licContactHtml()}
    <p class="label">Kod langganan</p>
    <textarea id="licInput" rows="3" placeholder="PBD1.xxxxx.xxxxx">${licEsc(lic.ok ? st.licCode : '')}</textarea>
    <button type="button" id="btnLicSave" class="primary">${lic.ok ? 'Kemas kini kod' : 'Aktifkan'}</button>
    <div id="licMsg" class="result hidden"></div>
    <p class="hint small">Percuma: Import, Pukal, Eksport. Langganan: Ulasan Guru, Usaha Murid, Ulasan Guru Kelas.</p>`;
  box.classList.remove('hidden');
  box.querySelector('.lic-x').addEventListener('click', () => box.classList.add('hidden'));
  licBindContact(box, lic.ok);
  document.getElementById('btnCopyDev').addEventListener('click', async (ev) => {
    await navigator.clipboard.writeText(dev);
    ev.target.textContent = 'Disalin ✓';
  });
  document.getElementById('btnLicSave').addEventListener('click', async () => {
    const code = document.getElementById('licInput').value.trim();
    const msg = document.getElementById('licMsg');
    const res = await licVerify(code, dev);
    msg.classList.remove('hidden');
    if (res.ok) {
      await chrome.storage.local.set({ licCode: code });
      lic.ok = true;
      lic.info = res;
      msg.className = 'result ok';
      msg.innerHTML = `✅ Berjaya diaktifkan. Terima kasih, ${licEsc(res.payload.n || '')}!`;
      licApplyLocks();
      setTimeout(() => licOpenPanel(), 900);
    } else {
      msg.className = 'result err';
      msg.textContent = res.reason;
    }
  });
  if (focus) document.getElementById('licInput').focus();
  box.scrollIntoView({ block: 'start' });
}

async function licInit() {
  const dev = await licDeviceId();
  const st = await chrome.storage.local.get('licCode');
  lic.info = st.licCode ? await licVerify(st.licCode, dev) : null;
  lic.ok = !!(lic.info && lic.info.ok);
  licApplyLocks();
  if (lic.ok && lic.info.daysLeft <= LIC_WARN_DAYS) {
    const s = document.getElementById('licWarn');
    if (s) {
      s.innerHTML = `⏳ Langganan anda tamat dalam <b>${lic.info.daysLeft} hari</b> (${licFmtDate(lic.info.payload.x)}). Hubungi pembangun untuk pembaharuan.` + licContactHtml();
      licBindContact(s, true);
      s.classList.remove('hidden');
    }
  }
  return lic.ok;
}

function licRequire() {
  if (lic.ok) return true;
  licOpenPanel(true);
  return false;
}

if (typeof document !== 'undefined') document.addEventListener('DOMContentLoaded', () => { licInit(); });
if (typeof module !== 'undefined') module.exports = { licVerify, b64urlToBytes };
