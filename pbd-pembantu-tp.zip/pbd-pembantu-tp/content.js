/*
 * PBD Pembantu TP — skrip kandungan
 * Dimasukkan ke dalam halaman PBD (semua frame) apabila popup dibuka.
 * Ia mengesan medan TP (dropdown <select> atau butang radio bernilai 1–6)
 * dan menyediakan arahan: scan, highlight, fill, bulk, export.
 * Extension ini TIDAK menekan butang "Simpan" — guru perlu semak dan simpan sendiri.
 */
(function () {
  if (window.__pbdHelper) return;

  const STYLE_ID = 'pbdx-style';
  const TP_RE = /^(?:TP\s*)?([0-6])(?:\s*[-–:.].*)?$/i;

  function tpOf(text) {
    if (text == null) return null;
    const m = String(text).trim().match(TP_RE);
    return m ? Number(m[1]) : null;
  }

  function clean(s) {
    return String(s || '').replace(/\s+/g, ' ').trim();
  }

  function normName(s) {
    return clean(s)
      .toUpperCase()
      .replace(/[^A-Z0-9@/ ]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function normIc(s) {
    const d = String(s || '').replace(/\D/g, '');
    return d.length === 12 ? d : '';
  }

  function isVisible(el) {
    if (!el || !el.getClientRects) return false;
    if (el.type === 'radio') {
      const lab = labelFor(el);
      if (lab && lab.getClientRects().length) return true;
    }
    return el.getClientRects().length > 0;
  }

  function labelFor(input) {
    if (input.id) {
      try {
        const l = document.querySelector('label[for="' + CSS.escape(input.id) + '"]');
        if (l) return l;
      } catch (e) { /* abaikan */ }
    }
    return input.closest('label');
  }

  // ---------- Pengesanan medan TP ----------

  function isTpSelect(sel) {
    const vals = new Set();
    for (const o of sel.options) {
      const v = tpOf(o.text);
      const w = tpOf(o.value);
      if (v !== null) vals.add(v);
      else if (w !== null) vals.add(w);
    }
    return vals.size >= 3;
  }

  function radioTp(r) {
    // utamakan teks label (nilai input mungkin ID pangkalan data)
    const lab = labelFor(r);
    if (lab) {
      const v = tpOf(lab.textContent);
      if (v !== null) return v;
    }
    const sib = r.nextElementSibling || (r.parentElement && r.parentElement.nextElementSibling);
    if (sib) {
      const v = tpOf(sib.textContent);
      if (v !== null) return v;
    }
    const al = r.getAttribute('aria-label');
    if (al && tpOf(al) !== null) return tpOf(al);
    return tpOf(r.value);
  }

  function isChecked(opt) {
    if (opt.input) {
      const w = opt.input.closest('.w-radio');
      if (w && /w-radio--(un)?checked/.test(w.className)) return w.classList.contains('w-radio--checked');
      return opt.input.checked;
    }
    const el = opt.el;
    const host = el.closest('[role="radio"]') || el;
    if (host.getAttribute('aria-checked') === 'true') return true;
    const inp = host.querySelector && host.querySelector('input[type="radio"]');
    if (inp) return inp.checked;
    const re = /(^|[\s_-])(is-checked|checked|active|selected|marked|radiobox-marked|radio_button_checked)([\s_-]|$)/i;
    let n = host;
    for (let k = 0; k < 3 && n; k++, n = n.parentElement) {
      if (re.test(n.className && n.className.baseVal != null ? n.className.baseVal : n.className || '')) return true;
    }
    return !!(host.querySelector && [...host.querySelectorAll('*')].some((c) => re.test(typeof c.className === 'string' ? c.className : '')));
  }

  function rowOf(el) {
    return (
      el.closest('tr') ||
      el.closest('[role="row"]') ||
      el.closest('li') ||
      el.closest('.row') ||
      el.parentElement
    );
  }

  function cellOf(el, row) {
    let c = el;
    while (c && c.parentElement !== row) c = c.parentElement;
    return c;
  }

  function headerRowsFor(table) {
    let rows = table.tHead ? [...table.tHead.rows] : [];
    if (!rows.length) {
      const first = table.rows[0];
      if (first && first.querySelector('th')) rows.push(first);
    }
    if (!rows.length) {
      // jadual header berasingan (cth. Element UI / Vuetify fixed header)
      let anc = table.parentElement;
      for (let k = 0; k < 5 && anc && !rows.length; k++, anc = anc.parentElement) {
        for (const t of anc.querySelectorAll('table')) {
          if (t === table) continue;
          if (t.tHead && t.tHead.rows.length) { rows = [...t.tHead.rows]; break; }
        }
      }
    }
    return rows;
  }

  function cellIndex(row, cell) {
    let idx = 0;
    for (const c of row.children) {
      if (c === cell) return idx;
      idx += c.colSpan || 1;
    }
    return -1;
  }

  function headerFor(row, cell) {
    if (!row || !cell || row.tagName !== 'TR') return '';
    const table = row.closest('table');
    if (!table) return '';
    const idx = cellIndex(row, cell);
    const headRows = headerRowsFor(table).filter((r) => r !== row);
    for (let i = headRows.length - 1; i >= 0; i--) {
      let k = 0;
      for (const th of headRows[i].children) {
        const span = th.colSpan || 1;
        if (idx >= k && idx < k + span) {
          const t = clean(th.textContent).replace(/\*$/, '').trim();
          if (t) return t;
          break;
        }
        k += span;
      }
    }
    return '';
  }

  function rowInfo(row) {
    const info = { name: '', ic: '' };
    if (!row) return info;
    const cells = row.children.length ? [...row.children] : [row];
    let best = '';
    let nameLocked = false;
    for (const c of cells) {
      if (c.querySelector && c.querySelector('select, input[type="radio"], [role="radio"], .pbdx-opt')) continue;
      const t = clean(c.textContent);
      if (row.tagName === 'TR' && /nama/i.test(headerFor(row, c) || (c.dataset && c.dataset.label) || '') && /[A-Za-z]{2,}/.test(t)) { best = t; nameLocked = true; continue; }
      if (!t) continue;
      const ic = t.match(/\b\d{6}-?\d{2}-?\d{4}\b/);
      if (ic && !info.ic) {
        info.ic = normIc(ic[0]);
        continue;
      }
      // nama: ada huruf, bukan nombor semata-mata
      if (/[A-Za-z]{2,}/.test(t) && t.length > best.length && t.length < 120 && !nameLocked) best = t;
    }
    info.name = best;
    return info;
  }

  function scanFields() {
    const fields = [];

    document.querySelectorAll('select').forEach((sel) => {
      if (sel.disabled || !isVisible(sel) || !isTpSelect(sel)) return;
      fields.push({ type: 'select', el: sel });
    });

    const groups = new Map();
    const add = (key, opt) => {
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(opt);
    };
    const groupKeyFor = (el) =>
      el.closest('td, [role="cell"], [role="gridcell"], [role="radiogroup"]') || rowOf(el);

    // 1) input radio sebenar — kumpul ikut sel jadual; pecahkan ikut `name`
    //    hanya jika setiap kumpulan name itu sendiri lengkap (≥3 TP).
    //    (SPPB / Wave UI memberi name unik pada setiap butang.)
    const byCell = new Map();
    document.querySelectorAll('input[type="radio"]').forEach((r) => {
      if (r.disabled) return;
      const tp = radioTp(r);
      if (tp === null) return;
      const cell = groupKeyFor(r);
      if (!byCell.has(cell)) byCell.set(cell, []);
      byCell.get(cell).push({ el: labelFor(r) || r, input: r, tp });
    });
    byCell.forEach((opts, cell) => {
      const byName = new Map();
      opts.forEach((o) => {
        const n = o.input.name || '';
        if (!byName.has(n)) byName.set(n, []);
        byName.get(n).push(o);
      });
      const parts = [...byName.values()];
      const allComplete = parts.length > 1 && parts.every((p) => new Set(p.map((o) => o.tp)).size >= 3);
      if (allComplete) parts.forEach((p) => p.forEach((o) => add('n|' + o.input.name, o)));
      else opts.forEach((o) => add(cell, o));
    });

    // 2) komponen tersuai: [role=radio] atau elemen teks "TP1".."TP6" tanpa input
    if (!groups.size) {
      const cand = document.querySelectorAll('[role="radio"], label, span, div, a, button, li, p');
      cand.forEach((el) => {
        if (el.closest('#pbdx-none') || el.querySelector('input[type="radio"]')) return;
        let tp = null;
        if (el.getAttribute('role') === 'radio') tp = tpOf(el.getAttribute('aria-label') || el.textContent);
        else if (![...el.children].some((c) => clean(c.textContent))) {
          const t = clean(el.textContent);
          if (/^TP\s*[1-6]$/i.test(t)) tp = tpOf(t);
        }
        if (tp === null || !isVisible(el)) return;
        const target = el.closest('[role="radio"], label, button, a') || el;
        const key = groupKeyFor(target);
        const list = groups.get(key);
        if (list && list.some((o) => o.el === target || o.el.contains(target) || target.contains(o.el))) return;
        add(key, { el: target, input: null, tp });
      });
    }

    groups.forEach((opts) => {
      const uniqTp = [...new Map(opts.map((o) => [o.tp, o])).values()];
      if (uniqTp.length >= 3 && opts.some((o) => isVisible(o.el))) {
        fields.push({ type: 'radio', el: opts[0].el, opts: uniqTp });
      }
    });

    // susun ikut kedudukan dalam dokumen
    fields.sort((a, b) =>
      a.el.compareDocumentPosition(b.el) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1
    );

    // kumpul ikut baris
    const rows = [];
    const rowMap = new Map();
    for (const f of fields) {
      const row = rowOf(f.el);
      let r = rowMap.get(row);
      if (!r) {
        r = { row, ...rowInfo(row), fields: [] };
        rowMap.set(row, r);
        rows.push(r);
      }
      const cell = cellOf(f.el, row);
      f.header = headerFor(row, cell) || (cell && cell.dataset && cell.dataset.label) || '';
      f.col = r.fields.length + 1;
      f.key = f.header || 'Kolum ' + f.col;
      r.fields.push(f);
    }
    return rows;
  }

  function getValue(f) {
    if (f.type === 'select') {
      const o = f.el.options[f.el.selectedIndex];
      if (!o) return null;
      const v = tpOf(o.text);
      return v !== null ? v : tpOf(o.value);
    }
    const o = f.opts.find(isChecked);
    return o ? o.tp : null;
  }

  function fire(el, types) {
    for (const t of types) el.dispatchEvent(new Event(t, { bubbles: true }));
  }

  function setValue(f, tp) {
    if (f.type === 'select') {
      const sel = f.el;
      const opt = [...sel.options].find((o) => tpOf(o.text) === tp) ||
        [...sel.options].find((o) => tpOf(o.value) === tp);
      if (!opt) return false;
      if (sel.value === opt.value) return true;
      const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set;
      setter.call(sel, opt.value);
      opt.selected = true;
      fire(sel, ['input', 'change']);
      if (window.jQuery) {
        try { window.jQuery(sel).trigger('change'); } catch (e) { /* abaikan */ }
      }
      mark(sel);
      return true;
    }
    const o = f.opts.find((x) => x.tp === tp);
    if (!o) return false;
    if (!isChecked(o)) {
      if (o.input) {
        o.input.click();
        if (!o.input.checked && o.el !== o.input) o.el.click();
        if (!o.input.checked) { o.input.checked = true; fire(o.input, ['input', 'change']); }
      } else {
        o.el.click();
      }
    }
    mark(o.el);
    return true;
  }

  // ---------- Paparan ----------

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = `
      .pbdx-hl { outline: 2px dashed #0e7c66 !important; outline-offset: 1px; }
      .pbdx-done { background-color: #d9f5e9 !important; transition: background-color .3s; }
      .pbdx-miss { background-color: #fde2e1 !important; }
      .pbdx-pick { width: 16px; height: 16px; margin: 0 6px 0 0; vertical-align: middle; accent-color: #0e7c66; cursor: pointer; }
    `;
    (document.head || document.documentElement).appendChild(s);
  }

  function mark(el) {
    if (!el) return;
    ensureStyle();
    el.classList.add('pbdx-done');
  }

  function highlight(on) {
    ensureStyle();
    document.querySelectorAll('.pbdx-pick').forEach((c) => c.remove());
    document.querySelectorAll('.pbdx-hl').forEach((e) => e.classList.remove('pbdx-hl'));
    if (!on) return 0;
    const rows = scanFields();
    rows.forEach((r, i) => {
      r.fields.forEach((f) => (f.type === 'select' ? f.el : (f.el.closest('td') || f.el)).classList.add('pbdx-hl'));
      const target = r.row && r.row.children.length ? r.row.children[0] : r.row;
      if (!target) return;
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.className = 'pbdx-pick';
      cb.title = 'Tanda baris ini untuk isian pukal (PBD Pembantu TP)';
      cb.dataset.idx = String(i);
      target.prepend(cb);
    });
    return rows.length;
  }

  function isPicked(r) {
    return !!(r.row && r.row.querySelector('.pbdx-pick:checked'));
  }

  // ---------- Padanan nama ----------

  function tokens(s) {
    const stop = new Set(['BIN', 'BINTI', 'BTE', 'BT', 'A/L', 'A/P', 'AL', 'AP', 'B', 'BN']);
    return normName(s).split(' ').filter((t) => t && !stop.has(t));
  }

  function similarity(a, b) {
    const A = tokens(a), B = tokens(b);
    if (!A.length || !B.length) return 0;
    const setB = new Set(B);
    const common = A.filter((t) => setB.has(t)).length;
    return (2 * common) / (A.length + B.length);
  }

  function findRecord(row, records, used) {
    if (row.ic) {
      const i = records.findIndex((r, k) => !used.has(k) && r.ic && r.ic === row.ic);
      if (i >= 0) return i;
    }
    const n = normName(row.name);
    if (n) {
      const i = records.findIndex((r, k) => !used.has(k) && normName(r.name) === n);
      if (i >= 0) return i;
    }
    let best = -1, score = 0;
    records.forEach((r, k) => {
      if (used.has(k) || !r.name) return;
      const s = similarity(r.name, row.name);
      if (s > score) { score = s; best = k; }
    });
    return score >= 0.75 ? best : -1;
  }

  // ---------- Arahan ----------

  function maskedHtml(el) {
    const clone = el.cloneNode(true);
    const walker = document.createTreeWalker(clone, NodeFilter.SHOW_TEXT);
    const keep = /^\s*(TP\s*[0-6]|[LP]|Bil\.?|Nama|ID Pengenalan|Jantina|Tahap Penguasaan\*?)\s*$/i;
    let n;
    while ((n = walker.nextNode())) {
      if (!keep.test(n.nodeValue)) n.nodeValue = n.nodeValue.replace(/[A-Za-z]/g, 'x').replace(/\d/g, '0');
    }
    clone.querySelectorAll('*').forEach((e) => {
      for (const a of [...e.attributes]) {
        if (/^(value|title|alt|aria-label)$/i.test(a.name) && !/^\s*(TP\s*)?[0-6]\s*$/i.test(a.value)) e.setAttribute(a.name, a.value.replace(/[A-Za-z]/g, 'x').replace(/\d/g, '0'));
      }
    });
    return clone.outerHTML.replace(/\s+/g, ' ').slice(0, 8000);
  }


  // ---------- Ulasan Guru (automasi tetingkap) ----------

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function waitFor(fn, timeout = 8000, step = 120) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      if (ulasanState.stop) throw new Error('Dihentikan oleh pengguna');
      try { const v = fn(); if (v) return v; } catch (e) { /* cuba lagi */ }
      await sleep(step);
    }
    return null;
  }

  function shown(el) {
    if (!el || !el.isConnected) return false;
    if (el.checkVisibility) return el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true });
    return el.getClientRects().length > 0;
  }

  function leafs(root, re) {
    const out = [];
    root.querySelectorAll('*').forEach((el) => {
      if ([...el.children].some((c) => clean(c.textContent))) return;
      if (re.test(clean(el.textContent)) && shown(el)) out.push(el);
    });
    return out;
  }

  // cari panel/tetingkap yang tajuknya `title` dan mengandungi teks `must`
  function findPanel(title, must) {
    const titles = leafs(document.body, new RegExp('^' + title + '$', 'i')).filter((t) => !t.closest('th, thead, td'));
    for (const t of titles.reverse()) {
      let p = t.parentElement;
      for (let k = 0; k < 8 && p && p !== document.body; k++, p = p.parentElement) {
        if (must.test(p.textContent) && p.querySelector('button, .w-button, [role="button"]')) return p;
      }
    }
    return null;
  }

  function buttonsIn(root, re) {
    return [...root.querySelectorAll('button, .w-button, [role="button"], a')]
      .filter((b) => re.test(clean(b.textContent)) && shown(b));
  }

  function isDisabled(b) {
    return b.disabled || b.getAttribute('aria-disabled') === 'true' || /(^|\s)(w-button--disabled|disabled)(\s|$)/.test(b.className);
  }

  const ulasanState = { running: false, stop: false };

  function overlay() {
    let o = document.getElementById('pbdx-overlay');
    if (!o) {
      o = document.createElement('div');
      o.id = 'pbdx-overlay';
      o.style.cssText = 'position:fixed;right:16px;bottom:70px;z-index:2147483647;width:300px;background:#fff;border:2px solid #0e7c66;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.25);font:13px/1.4 "Segoe UI",system-ui,sans-serif;color:#1d2a27;';
      o.innerHTML = '<div style="background:#0e7c66;color:#fff;padding:8px 12px;border-radius:7px 7px 0 0;font-weight:600;display:flex;justify-content:space-between;align-items:center"><span id="pbdx-title">PBD Pembantu — Ulasan &amp; Usaha</span><button id="pbdx-x" style="background:none;border:0;color:#fff;font-size:16px;cursor:pointer">×</button></div>' +
        '<div style="padding:10px 12px"><div id="pbdx-msg"></div><div style="height:6px;background:#e3f4ef;border-radius:3px;margin:8px 0"><div id="pbdx-bar" style="height:6px;width:0;background:#0e7c66;border-radius:3px;transition:width .3s"></div></div>' +
        '<div id="pbdx-log" style="max-height:120px;overflow:auto;font-size:11px;color:#61706c"></div>' +
        '<button id="pbdx-stop" style="margin-top:8px;width:100%;padding:6px;border:1px solid #b3261e;color:#b3261e;background:#fff;border-radius:6px;cursor:pointer;font-weight:600">Henti</button></div>';
      document.body.appendChild(o);
      o.querySelector('#pbdx-stop').onclick = () => { ulasanState.stop = true; };
      o.querySelector('#pbdx-x').onclick = () => { if (!ulasanState.running) o.remove(); else ulasanState.stop = true; };
    }
    return o;
  }

  function ovMsg(html, pct) {
    const o = overlay();
    o.querySelector('#pbdx-msg').innerHTML = html;
    if (pct != null) o.querySelector('#pbdx-bar').style.width = pct + '%';
  }
  function ovLog(txt, bad) {
    const l = overlay().querySelector('#pbdx-log');
    const d = document.createElement('div');
    d.textContent = txt;
    if (bad) d.style.color = '#b3261e';
    l.prepend(d);
  }

  function pickNumber(spec) {
    if (!String(spec || '').trim() || /^(\*|r|rawak|semua)$/i.test(String(spec).trim())) return 'rawak';
    const nums = String(spec || '1').split(/[,\s]+/).flatMap((p) => {
      const m = p.match(/^(\d+)-(\d+)$/);
      if (m) { const a = []; for (let i = +m[1]; i <= +m[2]; i++) a.push(i); return a; }
      return /^\d+$/.test(p) ? [Number(p)] : [];
    });
    if (!nums.length) return 1;
    return nums[Math.floor(Math.random() * nums.length)];
  }

  async function doOneUlasan(r, kategori, no) {
    let picked = no;
    const cell = [...r.row.children].find((td) => /ulasan/i.test((td.dataset && td.dataset.label) || headerFor(r.row, td)));
    if (!cell) throw new Error('Lajur "Ulasan Guru" tidak dijumpai');
    const btn = cell.querySelector('button, a, [role="button"], i, .w-icon') || cell.firstElementChild;
    btn.click();

    // 1) tetingkap Ulasan Guru
    const dlg = await waitFor(() => findPanel('Ulasan Guru', /Kategori/i));
    if (!dlg) throw new Error('Tetingkap "Ulasan Guru" tidak muncul');
    await sleep(250);
    const dtext = dlg.textContent.replace(/\D/g, '');
    if (r.ic && !dtext.includes(r.ic)) throw new Error('ID dalam tetingkap tidak sepadan — dihentikan untuk keselamatan');

    // 2) kategori
    const catEl = [...dlg.querySelectorAll('label')].find((l) => clean(l.textContent).toUpperCase() === kategori) ||
      leafs(dlg, new RegExp('^' + kategori + '$', 'i'))[0];
    if (!catEl) throw new Error('Kategori ' + kategori + ' tidak dijumpai');
    catEl.click();
    await sleep(250);

    // 3) buka senarai ulasan (ikon folder)
    const folder = dlg.querySelector('[class*="folder"]') ||
      (leafs(dlg, /^Ulasan\*?$/i)[0] || {}).nextElementSibling;
    if (!folder) throw new Error('Ikon pilih ulasan (📂) tidak dijumpai');
    (folder.closest('button, a, [role="button"]') || folder).click();

    const picker = await waitFor(() => findPanel('Sila Pilih', /Keterangan|Pilih/i));
    if (!picker) throw new Error('Senarai "Sila Pilih" tidak muncul');
    await sleep(200);
    const pilih = buttonsIn(picker, /^Pilih$/i);
    if (!pilih.length) throw new Error('Tiada butang "Pilih" dalam senarai');
    if (no === 'rawak') no = 1 + Math.floor(Math.random() * pilih.length);
    let target = pilih.find((b) => {
      const tr = b.closest('tr');
      return tr && parseInt(clean(tr.cells[0] && tr.cells[0].textContent), 10) === no;
    }) || pilih[no - 1];
    if (!target) throw new Error('Ulasan nombor ' + no + ' tiada (hanya ' + pilih.length + ')');
    picked = no;
    const tr = target.closest('tr');
    const ulasanText = tr ? clean([...tr.cells].map((c) => c.textContent).join(' ')).replace(/Pilih$/, '').trim() : '';
    target.click();
    await waitFor(() => !shown(picker), 5000);
    await sleep(300);

    // 4) Simpan dalam tetingkap
    const save = await waitFor(() => buttonsIn(dlg, /Simpan/i).find((b) => !isDisabled(b)), 6000);
    if (!save) throw new Error('Butang Simpan tidak aktif (ulasan tidak terisi?)');
    save.click();
    const closed = await waitFor(() => !shown(dlg) || !findPanel('Ulasan Guru', /Kategori/i), 10000);
    if (!closed) {
      // mungkin ada pengesahan
      const ok = buttonsIn(document.body, /^(Ya|OK|Teruskan|Sahkan)$/i)[0];
      if (ok) { ok.click(); await waitFor(() => !shown(dlg), 8000); }
      if (shown(dlg)) throw new Error('Tetingkap tidak tertutup selepas Simpan');
    }
    await sleep(300);
    // tutup notifikasi pengesahan ringkas jika ada
    const ok2 = buttonsIn(document.body, /^(OK|Ya|Tutup)$/i).find((b) => b.closest('[class*="dialog"], [class*="modal"], [role="dialog"], [class*="alert"], [class*="notif"]'));
    if (ok2 && !findPanel('Ulasan Guru', /Kategori/i)) { ok2.click(); await sleep(200); }
    return { no: picked, text: ulasanText };
  }

  function closeMenus() {
    const ae = document.activeElement;
    for (const t of [ae, document.body]) {
      if (t) t.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    }
  }

  async function doUsaha(r, level) {
    const cell = [...r.row.children].find((td) => /usaha/i.test((td.dataset && td.dataset.label) || headerFor(r.row, td)));
    if (!cell) throw new Error('Lajur "Usaha Murid" tidak dijumpai');
    const disp = cell.querySelector('input.w-select__selection') || cell.querySelector('input[readonly]');
    const hidden = cell.querySelector('input[type="hidden"]');
    const slot = () => cell.querySelector('.w-select__selection-slot, .w-select__selection');
    const cur = () => clean(disp ? disp.value : '').toUpperCase() ||
      clean(slot() && slot().textContent).toUpperCase();
    if (cur() === level) return 'sama';
    const hBefore = hidden ? hidden.value : null;
    const changed = () => cur() === level || (hidden && hidden.value !== hBefore && hidden.value !== '');

    const wrap = ['[aria-haspopup="listbox"]', '.w-select__selection-wrap', '[role="button"]', '.w-select', 'input']
      .map((q) => cell.querySelector(q)).find(Boolean);
    if (!wrap) throw new Error('Kotak pilihan Usaha Murid tidak dijumpai');
    wrap.click();
    const menuId = wrap.getAttribute('aria-owns');

    // semua elemen yang teksnya sama dengan pilihan — paling dalam dahulu
    const candidates = () => {
      const menu = menuId && document.getElementById(menuId);
      const root = menu && shown(menu) ? menu : document.body;
      const all = [...root.querySelectorAll('[role="option"], .w-list__item, .w-list__item-label, li, li *, [role="option"] *')]
        .filter((e) => shown(e) && clean(e.textContent).toUpperCase() === level)
        .filter((e) => { const td = e.closest('td[data-label]'); return !td || td === cell; });
      return all.sort((x, y) => (x.contains(y) ? 1 : y.contains(x) ? -1 : 0));
    };
    const first = await waitFor(() => candidates().length, 4000);
    if (!first) { closeMenus(); throw new Error('Senarai pilihan "' + level + '" tidak muncul'); }

    const methods = [
      (el) => el.click(),
      (el) => { for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })); },
      (el) => { el.focus && el.focus(); for (const t of ['keydown', 'keyup']) el.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true })); },
    ];
    for (const m of methods) {
      const cands = candidates();
      if (!cands.length) {
        // menu tertutup tanpa perubahan — buka semula
        wrap.click();
        await waitFor(() => candidates().length, 2000);
      }
      for (const el of candidates()) {
        m(el);
        if (await waitFor(changed, 700, 100)) { await sleep(150); closeMenus(); return 'ok'; }
        if (!el.isConnected) break;
      }
    }
    try {
      const menu = (menuId && document.getElementById(menuId)) || (candidates()[0] || {}).parentElement;
      window.__pbdLastMenu = menu ? menu.outerHTML.replace(/\s+/g, ' ').slice(0, 4000) : '(tiada menu)';
      window.__pbdLastCell = maskedHtml(cell);
    } catch (e) { /* abaikan */ }
    closeMenus();
    throw new Error('Usaha Murid tidak berubah kepada ' + level);
  }


  // ---------- Ulasan Guru Kelas ----------

  function gkRows() {
    const out = [];
    document.querySelectorAll('tr').forEach((tr) => {
      const cells = [...tr.children].filter((c) => c.tagName === 'TD');
      if (cells.length < 5 || !shown(tr)) return;
      const label = (c) => clean((c.dataset && c.dataset.label) || headerFor(tr, c)).replace(/\*$/, '').trim();
      const ulCell = cells.find((c) => /ulasan guru kelas/i.test(label(c)));
      if (!ulCell) return;
      const r = { tr, ulCell, name: '', ic: '', sex: '', subjects: {} };
      cells.forEach((c) => {
        const L = label(c);
        const t = clean(c.textContent);
        if (c === ulCell || /^bil\.?$/i.test(L)) return;
        if (/^nama/i.test(L)) r.name = t;
        else if (/pengenalan|no\.?\s*k\/?p|mykid/i.test(L)) r.ic = t.replace(/\D/g, '');
        else if (/jantina/i.test(L)) r.sex = t;
        else {
          const m = t.match(/TP\s*([0-6])/i);
          if (m && L) r.subjects[L.toUpperCase()] = Number(m[1]);
        }
      });
      if (r.name || r.ic) out.push(r);
    });
    return out;
  }

  function findGkDialog() {
    const tas = [...document.querySelectorAll('textarea, [contenteditable="true"]')]
      .filter((t) => shown(t) && !t.closest('table td[data-label]') && !t.closest('#pbdx-overlay'));
    for (const ta of tas) {
      let p = ta.parentElement;
      for (let k = 0; k < 10 && p && p !== document.body; k++, p = p.parentElement) {
        if (buttonsIn(p, /Simpan/i).length) return { dlg: p, ta };
      }
    }
    return null;
  }

  function setText(ta, text) {
    if (ta.isContentEditable) {
      ta.focus();
      ta.textContent = text;
      ta.dispatchEvent(new InputEvent('input', { bubbles: true }));
      return;
    }
    const max = ta.maxLength > 0 ? ta.maxLength : 0;
    if (max && text.length > max) text = text.slice(0, max - 1).replace(/\s\S*$/, '') + '.';
    const proto = ta.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    ta.focus();
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(ta, text);
    ta.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
    ta.dispatchEvent(new Event('change', { bubbles: true }));
    ta.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: '.' }));
    ta.blur();
  }

  function alertInfo(dlg) {
    const pops = [...document.querySelectorAll('.swal2-popup, .swal-modal, [role="alertdialog"], .w-notification, .w-alert, [class*="toast"], [class*="notif"]')]
      .filter((p) => shown(p) && !(dlg && dlg.contains(p)) && !p.closest('#pbdx-overlay'));
    const text = pops.map((p) => clean(p.textContent)).join(' ');
    const btns = [...document.querySelectorAll('.swal2-confirm, .swal-button--confirm, button, .w-button, [role="button"]')]
      .filter((b) => shown(b) && !(dlg && dlg.contains(b)) && !b.closest('#pbdx-overlay'))
      .filter((b) => b.matches('.swal2-confirm, .swal-button--confirm') ||
        (/^(OK|Ya|Baik|Teruskan|Sahkan)$/i.test(clean(b.textContent)) && b.closest('.swal2-popup, .swal-modal, [role="alertdialog"], [role="dialog"], [class*="dialog"], [class*="modal"], [class*="alert"]')));
    return { text, btn: btns[0] || null };
  }

  async function saveDialog(dlg, isOpen) {
    const save = await waitFor(() => buttonsIn(dlg, /Simpan/i).find((b) => !isDisabled(b)), 6000);
    if (!save) throw new Error('Butang Simpan tidak aktif');
    save.click();
    let success = false, errText = '', lastAlert = Date.now();
    const t0 = Date.now();
    while (Date.now() - t0 < 20000) {
      if (ulasanState.stop) throw new Error('Dihentikan oleh pengguna');
      await sleep(200);
      const { text, btn } = alertInfo(dlg);
      if (text) {
        lastAlert = Date.now();
        if (/berjaya|dikemaskini|disimpan|success/i.test(text)) success = true;
        else if (/gagal|ralat|error|tidak berjaya/i.test(text)) errText = text.slice(0, 120);
      }
      if (btn) {
        await sleep(250);
        btn.click();
        lastAlert = Date.now();
        await sleep(500);
        continue;
      }
      if (!isOpen()) {
        // tunggu sebentar jika mesej sistem muncul selepas tetingkap ditutup
        const t1 = Date.now();
        while (Date.now() - t1 < 1200) {
          const a = alertInfo(null);
          if (a.text && /gagal|ralat|error|tidak berjaya/i.test(a.text) && !/berjaya dikemaskini/i.test(a.text)) errText = a.text.slice(0, 120);
          if (a.btn) { await sleep(250); a.btn.click(); await sleep(400); }
          else await sleep(200);
        }
        if (errText) throw new Error('Sistem: ' + errText);
        return;
      }
      // berjaya disimpan tetapi tetingkap masih terbuka — tutup sendiri
      if (success && Date.now() - lastAlert > 1500) {
        const c = buttonsIn(dlg, /^Tutup$/i)[0];
        if (c) { c.click(); await waitFor(() => !isOpen(), 3000); }
        return;
      }
    }
    if (errText) throw new Error('Sistem: ' + errText);
    if (success) return;
    throw new Error('Tetingkap tidak tertutup selepas Simpan');
  }

  async function doGk(r, text, skipExisting) {
    const btn = r.ulCell.querySelector('button, a, [role="button"], i, .w-icon') || r.ulCell.firstElementChild;
    if (!btn) throw new Error('Ikon ulasan tidak dijumpai');
    btn.click();
    const found = await waitFor(findGkDialog, 7000);
    if (!found) {
      const pick = findPanel('Ulasan Guru( Kelas)?', /Simpan/i);
      if (pick) window.__pbdLastCell = maskedHtml(pick);
      throw new Error(pick ? 'Tetingkap ulasan tiada kotak teks (hantar diagnostik)' : 'Tetingkap ulasan tidak muncul');
    }
    const { dlg, ta } = found;
    await sleep(250);
    const digits = (dlg.textContent.match(/\d{12}/g) || []);
    if (r.ic && digits.length && !digits.includes(r.ic)) throw new Error('ID dalam tetingkap tidak sepadan — dihentikan untuk keselamatan');
    const existing = clean(ta.isContentEditable ? ta.textContent : ta.value);
    if (skipExisting && existing) {
      const c = buttonsIn(dlg, /^Tutup$/i)[0];
      if (c) c.click();
      await waitFor(() => !findGkDialog(), 4000);
      return 'langkau';
    }
    setText(ta, text);
    await sleep(200);
    await saveDialog(dlg, () => shown(ta));
    return 'ok';
  }

  async function runGk({ items, limit, skipExisting }) {
    ulasanState.running = true;
    ulasanState.stop = false;
    const rows = gkRows();
    const byIc = new Map(rows.map((r) => [r.ic, r]));
    const byName = new Map(rows.map((r) => [normName(r.name), r]));
    const list = (limit ? items.slice(0, limit) : items);
    overlay().querySelector('#pbdx-title').textContent = 'PBD Pembantu — Ulasan Guru Kelas';
    overlay().querySelector('#pbdx-log').innerHTML = '';
    let ok = 0, fail = 0, skip = 0;
    for (let i = 0; i < list.length; i++) {
      if (ulasanState.stop) break;
      const it = list[i];
      const r = byIc.get(it.ic) || byName.get(normName(it.name));
      ovMsg(`<b>${i + 1}/${list.length}</b> ${it.name}`, (i / list.length) * 100);
      if (!r) { fail++; ovLog('✖ ' + it.name + ': baris tidak dijumpai', true); continue; }
      { const a = alertInfo(null); if (a.btn) { a.btn.click(); await sleep(500); } }
      try {
        r.tr.scrollIntoView({ block: 'center' });
        const res = await doGk(r, it.text, skipExisting);
        if (res === 'langkau') { skip++; ovLog('↷ ' + it.name + ' — sudah ada ulasan, dilangkau'); } else { ok++; ovLog('✔ ' + it.name); }
      } catch (e) {
        fail++;
        ovLog('✖ ' + it.name + ': ' + e.message, true);
        const f = findGkDialog();
        if (f) { const c = buttonsIn(f.dlg, /^Tutup$/i)[0]; if (c) { c.click(); await sleep(400); } }
        if (/keselamatan|Dihentikan|tiada kotak teks|tidak muncul/.test(e.message)) break;
      }
      await sleep(300);
    }
    ulasanState.running = false;
    ovMsg(`${ulasanState.stop ? '⏹ Dihentikan.' : '✅ Selesai.'} <b>${ok} berjaya</b>` + (skip ? `, ${skip} dilangkau` : '') +
      (fail ? `, <span style="color:#b3261e">${fail} gagal</span>` : '') +
      '<br><small>Semak, kemudian tekan <b>Simpan</b> / <b>Hantar</b> di halaman PBD jika ada.</small>', 100);
    const st = overlay().querySelector('#pbdx-stop');
    st.textContent = 'Tutup';
    st.onclick = () => overlay().remove();
  }

  async function runUlasan({ map, picks, onlyPicked, limit, delay, doUlasan = true, doUsahaCol = false, usahaMap = {} }) {
    ulasanState.running = true;
    ulasanState.stop = false;
    if (overlay().querySelector('#pbdx-title')) overlay().querySelector('#pbdx-title').textContent = 'PBD Pembantu — Ulasan & Usaha';
    const rows = scanFields().filter((r) => !onlyPicked || isPicked(r));
    const todo = [];
    rows.forEach((r) => {
      const tp = r.fields.length ? getValue(r.fields[0]) : null;
      if (tp) todo.push({ r, tp });
    });
    const list = limit ? todo.slice(0, limit) : todo;
    let ok = 0, fail = 0;
    overlay().querySelector('#pbdx-log').innerHTML = '';
    ovMsg(`Bermula… ${list.length} murid` + (rows.length - todo.length ? ` (${rows.length - todo.length} tiada TP, dilangkau)` : ''), 0);
    for (let i = 0; i < list.length; i++) {
      if (ulasanState.stop) break;
      const { r, tp } = list[i];
      const kat = (map[tp] || 'SEDERHANA').toUpperCase();
      const no = pickNumber(picks[kat]);
      const usaha = (usahaMap[tp] || '').toUpperCase();
      ovMsg(`<b>${i + 1}/${list.length}</b> ${r.name}<br>TP${tp}` + (doUlasan ? ` → ${kat}` : '') + (doUsahaCol ? ` · Usaha: ${usaha}` : ''), (i / list.length) * 100);
      try {
        r.row.scrollIntoView({ block: 'center' });
        const parts = [];
        if (doUlasan) {
          const u = await doOneUlasan(r, kat, no);
          parts.push(kat + ' #' + u.no);
        }
        if (doUsahaCol && usaha) {
          await doUsaha(r, usaha);
          parts.push('Usaha ' + usaha);
        }
        ok++;
        ovLog('✔ ' + r.name + ' — ' + parts.join(', '));
      } catch (e) {
        fail++;
        ovLog('✖ ' + r.name + ': ' + e.message, true);
        // cuba tutup tetingkap yang masih terbuka
        for (const t of ['Sila Pilih', 'Ulasan Guru']) {
          const p = findPanel(t, /./);
          if (p) { const c = buttonsIn(p, /^Tutup$/i)[0]; if (c) { c.click(); await sleep(400); } }
        }
        if (/keselamatan|Dihentikan/.test(e.message)) break;
      }
      await sleep(delay || 400);
    }
    ulasanState.running = false;
    const stopped = ulasanState.stop;
    ovMsg(`${stopped ? '⏹ Dihentikan.' : '✅ Selesai.'} <b>${ok} berjaya</b>` + (fail ? `, <span style="color:#b3261e">${fail} gagal</span>` : '') +
      '<br><small>Semak, kemudian tekan <b>Simpan</b> / <b>Hantar</b> di halaman PBD.</small>', 100);
    const st = overlay().querySelector('#pbdx-stop');
    st.textContent = 'Tutup';
    st.onclick = () => overlay().remove();
  }

  const commands = {
    gkScan() {
      return { rows: gkRows().map((r) => ({ name: r.name, ic: r.ic, sex: r.sex, subjects: r.subjects })) };
    },

    gkFill(args) {
      if (ulasanState.running) return { error: 'Proses lain sedang berjalan' };
      if (!gkRows().length) return { started: false };
      runGk(args).catch((e) => { ulasanState.running = false; ovMsg('Ralat: ' + e.message); });
      return { started: true };
    },

    ulasan(args) {
      if (ulasanState.running) return { error: 'Proses ulasan sedang berjalan' };
      const rows = scanFields();
      if (!rows.length) return { started: false, rows: 0 };
      runUlasan(args).catch((e) => { ulasanState.running = false; ovMsg('Ralat: ' + e.message); });
      return { started: true, rows: rows.length };
    },

    diag() {
      let tpEl = null;
      for (const el of document.querySelectorAll('body *')) {
        if (![...el.children].some((c) => clean(c.textContent)) && /^TP\s*1$/i.test(clean(el.textContent))) { tpEl = el; break; }
      }
      let snippet = '';
      if (tpEl) {
        const row = tpEl.closest('tr, [role="row"]') || tpEl.parentElement.parentElement.parentElement;
        snippet = maskedHtml(row);
      }
      return {
        host: location.host,
        path: location.pathname,
        top: window === window.top,
        selects: document.querySelectorAll('select').length,
        radios: document.querySelectorAll('input[type="radio"]').length,
        roleRadios: document.querySelectorAll('[role="radio"]').length,
        iframes: [...document.querySelectorAll('iframe')].map((f) => { try { return new URL(f.src, location.href).host; } catch (e) { return '?'; } }),
        tp1Found: !!tpEl,
        fields: scanFields().reduce((n, r) => n + r.fields.length, 0),
        snippet,
        lastMenu: window.__pbdLastMenu || '',
        lastCell: window.__pbdLastCell || '',
      };
    },

    scan() {
      const rows = scanFields();
      const headers = [];
      rows.forEach((r) => r.fields.forEach((f) => { if (!headers.includes(f.key)) headers.push(f.key); }));
      return {
        url: location.href,
        title: document.title,
        rowCount: rows.length,
        fieldCount: rows.reduce((n, r) => n + r.fields.length, 0),
        headers,
        sample: rows.slice(0, 3).map((r) => r.name || '(tiada nama)'),
      };
    },

    highlight({ on }) {
      return { rows: highlight(on) };
    },

    export() {
      const rows = scanFields();
      const headers = [];
      rows.forEach((r) => r.fields.forEach((f) => { if (!headers.includes(f.key)) headers.push(f.key); }));
      return {
        headers,
        rows: rows.map((r, i) => {
          const vals = {};
          r.fields.forEach((f) => { vals[f.key] = getValue(f); });
          return { bil: i + 1, name: r.name, ic: r.ic, values: vals };
        }),
      };
    },

    bulk({ tp, col, onlyEmpty, onlyPicked }) {
      const rows = scanFields();
      let filled = 0, skipped = 0;
      for (const r of rows) {
        if (onlyPicked && !isPicked(r)) continue;
        for (const f of r.fields) {
          if (col !== 'all' && f.key !== col) continue;
          if (onlyEmpty && getValue(f) !== null) { skipped++; continue; }
          if (setValue(f, tp)) filled++;
        }
      }
      return { filled, skipped, rows: rows.length };
    },

    fill({ records, col, onlyEmpty, byOrder }) {
      // records: [{name, ic, values: {key: tp}, tp}]
      const rows = scanFields();
      const used = new Set();
      let filled = 0, skipped = 0;
      const unmatchedRows = [];
      rows.forEach((r, idx) => {
        const k = byOrder ? (idx < records.length ? idx : -1) : findRecord(r, records, used);
        if (k < 0) {
          unmatchedRows.push(r.name || '(baris ' + (idx + 1) + ')');
          if (r.row) { ensureStyle(); r.row.classList.add('pbdx-miss'); }
          return;
        }
        used.add(k);
        if (r.row) r.row.classList.remove('pbdx-miss');
        const rec = records[k];
        for (const f of r.fields) {
          let tp = null;
          if (rec.values && rec.values[f.key] != null) tp = rec.values[f.key];
          else if (rec.tp != null && (col === 'all' || f.key === col)) tp = rec.tp;
          if (tp == null) continue;
          if (onlyEmpty && getValue(f) !== null) { skipped++; continue; }
          if (setValue(f, tp)) filled++;
        }
      });
      const unusedRecords = records.filter((_, k) => !used.has(k)).map((r) => r.name || r.ic);
      return { filled, skipped, rows: rows.length, unmatchedRows, unusedRecords };
    },
  };

  window.__pbdHelper = {
    run(cmd, args) {
      try {
        if (!commands[cmd]) return { error: 'Arahan tidak dikenali: ' + cmd };
        return commands[cmd](args || {});
      } catch (e) {
        return { error: String(e && e.message || e) };
      }
    },
    _test: { tpOf, normName, similarity },
  };
})();
