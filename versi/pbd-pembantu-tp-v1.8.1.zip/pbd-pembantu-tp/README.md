# PBD Pembantu TP — Chrome Extension

Membantu guru mengisi Tahap Penguasaan (TP) dalam Sistem PBD KPM (log masuk idMe).

## Fungsi
1. **Import** — baca fail Excel (.xlsx/.xls) atau CSV, atau tampal terus dari Excel/Google Sheets, kemudian isi TP ke halaman PBD secara automatik.
   - Padanan murid ikut **No KP** (jika ada), kemudian **nama** (tak sensitif huruf besar/kecil, abaikan BIN/BINTI/A/L/A/P), atau ikut **susunan baris**.
   - Jika tajuk kolum dalam fail sama dengan tajuk kolum di halaman (cth. `SP 1.1.1`), setiap kolum diisi ke tempatnya. Jika tidak, satu kolum TP diisi ke "Kolum sasaran" yang dipilih.
   - Murid di halaman yang tiada padanan ditanda **merah**.
2. **Pukal** — pilih TP 1–6 dan isi untuk semua murid, atau hanya baris yang ditanda (☑).
3. **Eksport** — simpan senarai murid + TP semasa ke Excel atau CSV. Fail ini boleh diedit dan diimport semula.

> Extension ini **tidak** menekan butang Simpan. Selepas mengisi, semak dahulu dan tekan **Simpan** dalam sistem PBD sendiri.

## Tukar markah peperiksaan → TP
1. Dalam Google Sheets, blok jadual (termasuk baris tajuk **Nama**, **Kelas**) → Ctrl+C. Atau muat turun: Fail → Muat turun → .xlsx.
2. Dalam popup, tab **Import**: tampal → **Baca data** (atau pilih fail).
3. Pilih **Kelas** (cth. 3 BERLIAN) dan **Sumber TP** (cth. *Markah: PraUASA %*).
4. Semak / ubah **julat markah → TP** (lalai: TP6 ≥ 85, TP5 ≥ 70, TP4 ≥ 55, TP3 ≥ 40, TP2 ≥ 20, TP1 = selebihnya). Julat disimpan untuk kegunaan seterusnya.
5. Pratonton taburan TP dipaparkan. Murid bertanda **TH** / kosong tidak diisi dan disenaraikan.
6. Buka halaman PBD kelas tersebut → **Isi TP ke halaman** → semak → Simpan.

## Ulasan Guru & Usaha Murid (automatik)
Tab **Ulasan**: TP yang sudah ditanda di halaman menentukan Kategori (lalai TP5–6 Cemerlang, TP3–4 Sederhana, TP1–2 Lemah). Bagi setiap kategori, ulasan dipilih **rawak** daripada senarai "Sila Pilih" (atau hadkan dengan `1,2,5` / `1-4`).
**Usaha Murid** diisi ikut TP (lalai: TP6 Sangat Tinggi, TP5 Tinggi, TP3–4 Sederhana, TP1–2 Rendah). Kedua-duanya boleh dihidupkan/dimatikan.
Klik **Uji 1 murid** dahulu, kemudian **Isi semua**. Extension akan membuka ✎ Ulasan Guru → pilih Kategori → 📂 → Pilih → Simpan untuk setiap murid. Kemajuan dipaparkan di penjuru kanan bawah halaman, dengan butang **Henti**. Jangan klik halaman semasa proses berjalan. Sebagai langkah keselamatan, proses berhenti jika ID dalam tetingkap tidak sepadan dengan baris murid.

## Ulasan Guru Kelas (guru kelas)
Buka halaman PBD Guru Kelas (jadual TP semua mata pelajaran + lajur "Ulasan Guru Kelas"). Tab **G. Kelas** → **Jana ulasan**: extension membaca TP setiap murid dan menjana ulasan khusus (gambaran keseluruhan, mata pelajaran terkuat, mata pelajaran yang perlu ditingkatkan dengan cadangan, dan kata galakan). Semua ulasan boleh diedit dalam popup. **Variasi lain** menjana ayat berbeza. **Uji 1 murid** → **Isi semua**. Pilihan "Langkau murid yang sudah ada ulasan" tersedia. **Salin semua** menyalin ulasan untuk ditampal ke Excel/Sheets.
Nama penuh mata pelajaran boleh diubah di bahagian "Nama mata pelajaran" (format `KOD=Nama`).

## Format fail import
| BIL | NAMA | NO KP (pilihan) | TP |
|-----|------|-----------------|----|
| 1 | ALI BIN ABU | 110101-10-1234 | 4 |
| 2 | SITI NUR BINTI AHMAD | 110202-10-5678 | 5 |

Nilai TP boleh ditulis `4` atau `TP4`. Untuk beberapa SP sekaligus, guna tajuk kolum yang sama seperti di halaman PBD (cara paling mudah: **Eksport** dahulu, isi, kemudian **Import**).

## Pemasangan
1. Unzip `pbd-pembantu-tp.zip` ke satu folder (cth. `Documents\pbd-pembantu-tp`).
2. Buka Chrome → `chrome://extensions`.
3. Hidupkan **Developer mode** (penjuru kanan atas).
4. Klik **Load unpacked** → pilih folder tadi.
5. Pin ikon **TP** pada toolbar.

## Cara guna
1. Log masuk Sistem PBD dan buka halaman pengisian TP (senarai murid dengan pilihan TP).
2. Klik ikon **TP**. Popup akan memaparkan bilangan murid dan medan TP yang dikesan.
3. Pilih tab Import / Pukal / Eksport.
4. Semak hasil, kemudian tekan **Simpan** dalam sistem PBD.

Untuk isian pukal pada baris tertentu: tandakan **"Tunjuk medan TP & kotak tanda baris"**, tanda ☑ pada baris di halaman, buka semula popup dan pilih **"Hanya baris yang ditanda"**.

## Jika tiada medan dikesan
Extension mengesan dropdown (`<select>`) atau butang radio yang mempunyai pilihan TP 1–6. Jika halaman PBD menggunakan reka bentuk lain, simpan halaman tersebut (Ctrl+S → "Webpage, HTML only") dan hantar kepada pembangun untuk diselaraskan. Pastikan maklumat murid sebenar dibuang/diganti dahulu.

## Langganan
- **Percuma:** Import (Excel/CSV/markah → TP), Pukal, Eksport.
- **Langganan:** Ulasan Guru, Usaha Murid, Ulasan Guru Kelas.
- Guru menyalin **Kod Peranti** dari popup (pautan "Versi percuma · Langgan" di bawah) dan memberikannya kepada pembangun. Pembangun menjana kod dengan `tools/penjana-kod.html` (perlukan fail kunci rahsia — **jangan sesekali commit**). Kod diikat pada satu komputer dan mempunyai tarikh tamat.
- Jika extension dibuang dan dipasang semula, Kod Peranti akan berubah dan kod baharu diperlukan. Reload/kemas kini biasa tidak menjejaskan Kod Peranti.

## Kemas kini
Popup menyemak versi baharu secara automatik (setiap 6 jam) dari repo awam `pbd-pembantu-tp-release`. Jika ada, kotak kuning dipaparkan dengan butang **Muat turun**. Unzip dan gantikan fail dalam folder extension yang sama (supaya tetapan kekal), kemudian ↻ Reload di `chrome://extensions`. Semakan manual: pautan **Semak kemas kini** di bawah popup.

### Untuk pembangun — terbitkan versi baharu
1. Naikkan `version` dalam `manifest.json`, commit & push repo ini.
2. `scripts/release.sh /laluan/ke/pbd-pembantu-tp-release "Nota perubahan 1" "Nota 2"`
3. Commit & push repo release.

## Privasi
Semua pemprosesan berlaku dalam pelayar anda. Tiada data murid dihantar ke mana-mana pelayan.
